import 'package:flutter/material.dart';
import 'package:rapidsport/core/app_export.dart';

class CustomTextFormField extends StatelessWidget {
  CustomTextFormField(
      {this.shape,
      this.padding,
      this.variant,
      this.fontStyle,
      this.alignment,
      this.width,
      this.margin,
      this.controller,
      this.focusNode,
      this.isObscureText = false,
      this.textInputAction = TextInputAction.next,
      this.textInputType = TextInputType.text,
      this.maxLines,
      this.hintText,
      this.prefix,
      this.prefixConstraints,
      this.suffix,
      this.suffixConstraints,
      this.validator});

  TextFormFieldShape? shape;

  TextFormFieldPadding? padding;

  TextFormFieldVariant? variant;

  TextFormFieldFontStyle? fontStyle;

  Alignment? alignment;

  double? width;

  EdgeInsetsGeometry? margin;

  TextEditingController? controller;

  FocusNode? focusNode;

  bool? isObscureText;

  TextInputAction? textInputAction;

  TextInputType? textInputType;

  int? maxLines;

  String? hintText;

  Widget? prefix;

  BoxConstraints? prefixConstraints;

  Widget? suffix;

  BoxConstraints? suffixConstraints;

  FormFieldValidator<String>? validator;

  @override
  Widget build(BuildContext context) {
    return alignment != null
        ? Align(
            alignment: alignment ?? Alignment.center,
            child: _buildTextFormFieldWidget(),
          )
        : _buildTextFormFieldWidget();
  }

  _buildTextFormFieldWidget() {
    return Container(
      width: width ?? double.maxFinite,
      margin: margin,
      child: TextFormField(
        controller: controller,
        focusNode: focusNode,
        style: _setFontStyle(),
        obscureText: isObscureText!,
        textInputAction: textInputAction,
        keyboardType: textInputType,
        maxLines: maxLines ?? 1,
        decoration: _buildDecoration(),
        validator: validator,
      ),
    );
  }

  _buildDecoration() {
    return InputDecoration(
      hintText: hintText ?? "",
      hintStyle: _setFontStyle(),
      border: _setBorderStyle(),
      enabledBorder: _setBorderStyle(),
      focusedBorder: _setBorderStyle(),
      disabledBorder: _setBorderStyle(),
      prefixIcon: prefix,
      prefixIconConstraints: prefixConstraints,
      suffixIcon: suffix,
      suffixIconConstraints: suffixConstraints,
      fillColor: _setFillColor(),
      filled: _setFilled(),
      isDense: true,
      contentPadding: _setPadding(),
    );
  }

  _setFontStyle() {
    switch (fontStyle) {
      case TextFormFieldFontStyle.ABeeZeeRegular17:
        return TextStyle(
          color: ColorConstant.blueGray200,
          fontSize: getFontSize(
            17,
          ),
          fontFamily: 'ABeeZee',
          fontWeight: FontWeight.w400,
        );
      case TextFormFieldFontStyle.DMSansRegular18:
        return TextStyle(
          color: ColorConstant.teal70066,
          fontSize: getFontSize(
            18,
          ),
          fontFamily: 'DM Sans',
          fontWeight: FontWeight.w400,
        );
      case TextFormFieldFontStyle.PTMonoRegular16:
        return TextStyle(
          color: ColorConstant.blueGray900A2,
          fontSize: getFontSize(
            16,
          ),
          fontFamily: 'PT Mono',
          fontWeight: FontWeight.w400,
        );
      default:
        return TextStyle(
          color: ColorConstant.black900,
          fontSize: getFontSize(
            16,
          ),
          fontFamily: 'Inter',
          fontWeight: FontWeight.w700,
        );
    }
  }

  _setOutlineBorderRadius() {
    switch (shape) {
      case TextFormFieldShape.RoundedBorder14:
        return BorderRadius.circular(
          getHorizontalSize(
            14.00,
          ),
        );
      case TextFormFieldShape.RoundedBorder4:
        return BorderRadius.circular(
          getHorizontalSize(
            4.00,
          ),
        );
      default:
        return BorderRadius.circular(
          getHorizontalSize(
            28.00,
          ),
        );
    }
  }

  _setBorderStyle() {
    switch (variant) {
      case TextFormFieldVariant.FillBluegray5001:
        return OutlineInputBorder(
          borderRadius: _setOutlineBorderRadius(),
          borderSide: BorderSide.none,
        );
      case TextFormFieldVariant.OutlineTeal70066:
        return OutlineInputBorder(
          borderRadius: _setOutlineBorderRadius(),
          borderSide: BorderSide(
            color: ColorConstant.teal70066,
            width: 1,
          ),
        );
      case TextFormFieldVariant.OutlineBluegray10001:
        return OutlineInputBorder(
          borderRadius: _setOutlineBorderRadius(),
          borderSide: BorderSide(
            color: ColorConstant.blueGray10001,
            width: 1,
          ),
        );
      case TextFormFieldVariant.None:
        return InputBorder.none;
      default:
        return OutlineInputBorder(
          borderRadius: _setOutlineBorderRadius(),
          borderSide: BorderSide.none,
        );
    }
  }

  _setFillColor() {
    switch (variant) {
      case TextFormFieldVariant.FillBluegray5001:
        return ColorConstant.blueGray5001;
      case TextFormFieldVariant.OutlineBluegray10001:
        return ColorConstant.whiteA700;
      default:
        return ColorConstant.teal70066;
    }
  }

  _setFilled() {
    switch (variant) {
      case TextFormFieldVariant.FillBluegray5001:
        return true;
      case TextFormFieldVariant.OutlineTeal70066:
        return false;
      case TextFormFieldVariant.OutlineBluegray10001:
        return true;
      case TextFormFieldVariant.None:
        return false;
      default:
        return true;
    }
  }

  _setPadding() {
    switch (padding) {
      case TextFormFieldPadding.PaddingT96:
        return getPadding(
          left: 13,
          top: 96,
          right: 13,
          bottom: 96,
        );
      case TextFormFieldPadding.PaddingT15:
        return getPadding(
          left: 13,
          top: 15,
          right: 13,
          bottom: 15,
        );
      case TextFormFieldPadding.PaddingT3:
        return getPadding(
          top: 3,
          bottom: 3,
        );
      default:
        return getPadding(
          all: 18,
        );
    }
  }
}

enum TextFormFieldShape {
  CircleBorder28,
  RoundedBorder14,
  RoundedBorder4,
}
enum TextFormFieldPadding {
  PaddingAll18,
  PaddingT96,
  PaddingT15,
  PaddingT3,
}
enum TextFormFieldVariant {
  None,
  FillTeal70066,
  FillBluegray5001,
  OutlineTeal70066,
  OutlineBluegray10001,
}
enum TextFormFieldFontStyle {
  InterBold16,
  ABeeZeeRegular17,
  DMSansRegular18,
  PTMonoRegular16,
}
