import 'package:rapidsport/core/app_export.dart';

class ApiClient {}
