import 'package:flutter/material.dart';
import 'package:rapidsport/presentation/ders_haz_r_screen/ders_haz_r_screen.dart';
import 'package:rapidsport/presentation/anasayfa_screen/anasayfa_screen.dart';
import 'package:rapidsport/presentation/yakindakiantrenorlerigor_screen/yakindakiantrenorlerigor_screen.dart';
import 'package:rapidsport/presentation/yakinantonay_screen/yakinantonay_screen.dart';
import 'package:rapidsport/presentation/dersonay_one_screen/dersonay_one_screen.dart';
import 'package:rapidsport/presentation/dersonay_screen/dersonay_screen.dart';
import 'package:rapidsport/presentation/egitmenler_screen/egitmenler_screen.dart';
import 'package:rapidsport/presentation/rezervasyonolusturma_screen/rezervasyonolusturma_screen.dart';
import 'package:rapidsport/presentation/rezervasyononay_screen/rezervasyononay_screen.dart';
import 'package:rapidsport/presentation/dersrezerveet_screen/dersrezerveet_screen.dart';
import 'package:rapidsport/presentation/rezervasyononaytwo_one_screen/rezervasyononaytwo_one_screen.dart';
import 'package:rapidsport/presentation/beslenmeprogrami_screen/beslenmeprogrami_screen.dart';
import 'package:rapidsport/presentation/beslenmehedef_screen/beslenmehedef_screen.dart';
import 'package:rapidsport/presentation/beslenmeboykilo_screen/beslenmeboykilo_screen.dart';
import 'package:rapidsport/presentation/beslenmefiziksel_screen/beslenmefiziksel_screen.dart';
import 'package:rapidsport/presentation/beslenmevegan_screen/beslenmevegan_screen.dart';
import 'package:rapidsport/presentation/beslenmeogun_screen/beslenmeogun_screen.dart';
import 'package:rapidsport/presentation/beslenmekalori_screen/beslenmekalori_screen.dart';
import 'package:rapidsport/presentation/beslenmeprogramsiz_screen/beslenmeprogramsiz_screen.dart';
import 'package:rapidsport/presentation/beslenmeprogramiprogram_screen/beslenmeprogramiprogram_screen.dart';
import 'package:rapidsport/presentation/antrenmansure_screen/antrenmansure_screen.dart';
import 'package:rapidsport/presentation/antrenmansiklik_screen/antrenmansiklik_screen.dart';
import 'package:rapidsport/presentation/antrenmantur_screen/antrenmantur_screen.dart';
import 'package:rapidsport/presentation/antrenmansalon_screen/antrenmansalon_screen.dart';
import 'package:rapidsport/presentation/antrenmanoneri_screen/antrenmanoneri_screen.dart';
import 'package:rapidsport/presentation/antrenmanprogrami_screen/antrenmanprogrami_screen.dart';
import 'package:rapidsport/presentation/antrenmanprogramsiz_screen/antrenmanprogramsiz_screen.dart';
import 'package:rapidsport/presentation/antrenmanprogramiprogram_screen/antrenmanprogramiprogram_screen.dart';
import 'package:rapidsport/presentation/ayarlar_two_screen/ayarlar_two_screen.dart';
import 'package:rapidsport/presentation/fiyatlandirma_screen/fiyatlandirma_screen.dart';
import 'package:rapidsport/presentation/paketsecimonaylama_screen/paketsecimonaylama_screen.dart';
import 'package:rapidsport/presentation/odemeyontemi_screen/odemeyontemi_screen.dart';
import 'package:rapidsport/presentation/odemebasari_screen/odemebasari_screen.dart';
import 'package:rapidsport/presentation/kaydol_screen/kaydol_screen.dart';
import 'package:rapidsport/presentation/telefononay_screen/telefononay_screen.dart';
import 'package:rapidsport/presentation/ders_haz_r_two_screen/ders_haz_r_two_screen.dart';
import 'package:rapidsport/presentation/ders_haz_r_four_screen/ders_haz_r_four_screen.dart';
import 'package:rapidsport/presentation/ayarlar_screen/ayarlar_screen.dart';
import 'package:rapidsport/presentation/rezervasyononaytwo_three_screen/rezervasyononaytwo_three_screen.dart';
import 'package:rapidsport/presentation/ders_haz_r_five_screen/ders_haz_r_five_screen.dart';
import 'package:rapidsport/presentation/rezervasyononaytwo_screen/rezervasyononaytwo_screen.dart';
import 'package:rapidsport/presentation/rezervasyononaytwo_two_screen/rezervasyononaytwo_two_screen.dart';
import 'package:rapidsport/presentation/ayarlar_one_screen/ayarlar_one_screen.dart';
import 'package:rapidsport/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String dersHazRScreen = '/ders_haz_r_screen';

  static const String anasayfaScreen = '/anasayfa_screen';

  static const String yakindakiantrenorlerigorScreen =
      '/yakindakiantrenorlerigor_screen';

  static const String yakinantonayScreen = '/yakinantonay_screen';

  static const String dersonayOneScreen = '/dersonay_one_screen';

  static const String dersonayScreen = '/dersonay_screen';

  static const String egitmenlerScreen = '/egitmenler_screen';

  static const String rezervasyonolusturmaScreen =
      '/rezervasyonolusturma_screen';

  static const String rezervasyononayScreen = '/rezervasyononay_screen';

  static const String dersrezerveetScreen = '/dersrezerveet_screen';

  static const String rezervasyononaytwoOneScreen =
      '/rezervasyononaytwo_one_screen';

  static const String beslenmeprogramiScreen = '/beslenmeprogrami_screen';

  static const String beslenmehedefScreen = '/beslenmehedef_screen';

  static const String beslenmeboykiloScreen = '/beslenmeboykilo_screen';

  static const String beslenmefizikselScreen = '/beslenmefiziksel_screen';

  static const String beslenmeveganScreen = '/beslenmevegan_screen';

  static const String beslenmeogunScreen = '/beslenmeogun_screen';

  static const String beslenmekaloriScreen = '/beslenmekalori_screen';

  static const String beslenmeprogramsizScreen = '/beslenmeprogramsiz_screen';

  static const String beslenmeprogramiprogramScreen =
      '/beslenmeprogramiprogram_screen';

  static const String antrenmansureScreen = '/antrenmansure_screen';

  static const String antrenmansiklikScreen = '/antrenmansiklik_screen';

  static const String antrenmanturScreen = '/antrenmantur_screen';

  static const String antrenmansalonScreen = '/antrenmansalon_screen';

  static const String antrenmanoneriScreen = '/antrenmanoneri_screen';

  static const String antrenmanprogramiScreen = '/antrenmanprogrami_screen';

  static const String antrenmanprogramsizScreen = '/antrenmanprogramsiz_screen';

  static const String antrenmanprogramiprogramScreen =
      '/antrenmanprogramiprogram_screen';

  static const String ayarlarTwoScreen = '/ayarlar_two_screen';

  static const String fiyatlandirmaScreen = '/fiyatlandirma_screen';

  static const String paketsecimonaylamaScreen = '/paketsecimonaylama_screen';

  static const String odemeyontemiScreen = '/odemeyontemi_screen';

  static const String odemebasariScreen = '/odemebasari_screen';

  static const String kaydolScreen = '/kaydol_screen';

  static const String telefononayScreen = '/telefononay_screen';

  static const String dersHazRTwoScreen = '/ders_haz_r_two_screen';

  static const String dersHazRFourScreen = '/ders_haz_r_four_screen';

  static const String ayarlarScreen = '/ayarlar_screen';

  static const String rezervasyononaytwoThreeScreen =
      '/rezervasyononaytwo_three_screen';

  static const String dersHazRFiveScreen = '/ders_haz_r_five_screen';

  static const String rezervasyononaytwoScreen = '/rezervasyononaytwo_screen';

  static const String rezervasyononaytwoTwoScreen =
      '/rezervasyononaytwo_two_screen';

  static const String ayarlarOneScreen = '/ayarlar_one_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> get routes => {
        dersHazRScreen: DersHazRScreen.builder,
        anasayfaScreen: AnasayfaScreen.builder,
        yakindakiantrenorlerigorScreen: YakindakiantrenorlerigorScreen.builder,
        yakinantonayScreen: YakinantonayScreen.builder,
        dersonayOneScreen: DersonayOneScreen.builder,
        dersonayScreen: DersonayScreen.builder,
        egitmenlerScreen: EgitmenlerScreen.builder,
        rezervasyonolusturmaScreen: RezervasyonolusturmaScreen.builder,
        rezervasyononayScreen: RezervasyononayScreen.builder,
        dersrezerveetScreen: DersrezerveetScreen.builder,
        rezervasyononaytwoOneScreen: RezervasyononaytwoOneScreen.builder,
        beslenmeprogramiScreen: BeslenmeprogramiScreen.builder,
        beslenmehedefScreen: BeslenmehedefScreen.builder,
        beslenmeboykiloScreen: BeslenmeboykiloScreen.builder,
        beslenmefizikselScreen: BeslenmefizikselScreen.builder,
        beslenmeveganScreen: BeslenmeveganScreen.builder,
        beslenmeogunScreen: BeslenmeogunScreen.builder,
        beslenmekaloriScreen: BeslenmekaloriScreen.builder,
        beslenmeprogramsizScreen: BeslenmeprogramsizScreen.builder,
        beslenmeprogramiprogramScreen: BeslenmeprogramiprogramScreen.builder,
        antrenmansureScreen: AntrenmansureScreen.builder,
        antrenmansiklikScreen: AntrenmansiklikScreen.builder,
        antrenmanturScreen: AntrenmanturScreen.builder,
        antrenmansalonScreen: AntrenmansalonScreen.builder,
        antrenmanoneriScreen: AntrenmanoneriScreen.builder,
        antrenmanprogramiScreen: AntrenmanprogramiScreen.builder,
        antrenmanprogramsizScreen: AntrenmanprogramsizScreen.builder,
        antrenmanprogramiprogramScreen: AntrenmanprogramiprogramScreen.builder,
        ayarlarTwoScreen: AyarlarTwoScreen.builder,
        fiyatlandirmaScreen: FiyatlandirmaScreen.builder,
        paketsecimonaylamaScreen: PaketsecimonaylamaScreen.builder,
        odemeyontemiScreen: OdemeyontemiScreen.builder,
        odemebasariScreen: OdemebasariScreen.builder,
        kaydolScreen: KaydolScreen.builder,
        telefononayScreen: TelefononayScreen.builder,
        dersHazRTwoScreen: DersHazRTwoScreen.builder,
        dersHazRFourScreen: DersHazRFourScreen.builder,
        ayarlarScreen: AyarlarScreen.builder,
        rezervasyononaytwoThreeScreen: RezervasyononaytwoThreeScreen.builder,
        dersHazRFiveScreen: DersHazRFiveScreen.builder,
        rezervasyononaytwoScreen: RezervasyononaytwoScreen.builder,
        rezervasyononaytwoTwoScreen: RezervasyononaytwoTwoScreen.builder,
        ayarlarOneScreen: AyarlarOneScreen.builder,
        appNavigationScreen: AppNavigationScreen.builder,
        initialRoute: AnasayfaScreen.builder
      };
}
