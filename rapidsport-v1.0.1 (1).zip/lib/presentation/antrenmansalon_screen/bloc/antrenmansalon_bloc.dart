import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/antrenmansalon_screen/models/antrenmansalon_model.dart';part 'antrenmansalon_event.dart';part 'antrenmansalon_state.dart';class AntrenmansalonBloc extends Bloc<AntrenmansalonEvent, AntrenmansalonState> {AntrenmansalonBloc(AntrenmansalonState initialState) : super(initialState) { on<AntrenmansalonInitialEvent>(_onInitialize); }

_onInitialize(AntrenmansalonInitialEvent event, Emitter<AntrenmansalonState> emit, ) async  {  } 
 }
