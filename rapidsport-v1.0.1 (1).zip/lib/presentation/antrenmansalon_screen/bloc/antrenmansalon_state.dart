// ignore_for_file: must_be_immutable

part of 'antrenmansalon_bloc.dart';

class AntrenmansalonState extends Equatable {
  AntrenmansalonState({this.antrenmansalonModelObj});

  AntrenmansalonModel? antrenmansalonModelObj;

  @override
  List<Object?> get props => [
        antrenmansalonModelObj,
      ];
  AntrenmansalonState copyWith({AntrenmansalonModel? antrenmansalonModelObj}) {
    return AntrenmansalonState(
      antrenmansalonModelObj:
          antrenmansalonModelObj ?? this.antrenmansalonModelObj,
    );
  }
}
