// ignore_for_file: must_be_immutable

part of 'antrenmansalon_bloc.dart';

@immutable
abstract class AntrenmansalonEvent extends Equatable {}

class AntrenmansalonInitialEvent extends AntrenmansalonEvent {
  @override
  List<Object?> get props => [];
}
