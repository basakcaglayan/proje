import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/beslenmeprogramsiz_screen/models/beslenmeprogramsiz_model.dart';part 'beslenmeprogramsiz_event.dart';part 'beslenmeprogramsiz_state.dart';class BeslenmeprogramsizBloc extends Bloc<BeslenmeprogramsizEvent, BeslenmeprogramsizState> {BeslenmeprogramsizBloc(BeslenmeprogramsizState initialState) : super(initialState) { on<BeslenmeprogramsizInitialEvent>(_onInitialize); }

_onInitialize(BeslenmeprogramsizInitialEvent event, Emitter<BeslenmeprogramsizState> emit, ) async  {  } 
 }
