// ignore_for_file: must_be_immutable

part of 'beslenmeprogramsiz_bloc.dart';

@immutable
abstract class BeslenmeprogramsizEvent extends Equatable {}

class BeslenmeprogramsizInitialEvent extends BeslenmeprogramsizEvent {
  @override
  List<Object?> get props => [];
}
