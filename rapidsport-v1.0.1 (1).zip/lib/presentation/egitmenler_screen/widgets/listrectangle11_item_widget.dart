import '../models/listrectangle11_item_model.dart';
import 'package:flutter/material.dart';
import 'package:rapidsport/core/app_export.dart';

// ignore: must_be_immutable
class Listrectangle11ItemWidget extends StatelessWidget {
  Listrectangle11ItemWidget(this.listrectangle11ItemModelObj);

  Listrectangle11ItemModel listrectangle11ItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: getPadding(
        left: 8,
        top: 3,
        right: 8,
        bottom: 3,
      ),
      decoration: AppDecoration.outlineBlack900143.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder5,
      ),
      child: Row(
        children: [
          Container(
            height: getSize(
              44,
            ),
            width: getSize(
              44,
            ),
            margin: getMargin(
              top: 4,
              bottom: 5,
            ),
            child: Stack(
              alignment: Alignment.bottomCenter,
              children: [
                Align(
                  alignment: Alignment.center,
                  child: Container(
                    height: getSize(
                      44,
                    ),
                    width: getSize(
                      44,
                    ),
                    decoration: BoxDecoration(
                      color: ColorConstant.blueGray100,
                      boxShadow: [
                        BoxShadow(
                          color: ColorConstant.black9003f,
                          spreadRadius: getHorizontalSize(
                            2,
                          ),
                          blurRadius: getHorizontalSize(
                            2,
                          ),
                          offset: Offset(
                            0,
                            4,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                CustomImageView(
                  svgPath: ImageConstant.imgSave,
                  height: getVerticalSize(
                    18,
                  ),
                  width: getHorizontalSize(
                    44,
                  ),
                  alignment: Alignment.bottomCenter,
                ),
                Align(
                  alignment: Alignment.topCenter,
                  child: Container(
                    height: getVerticalSize(
                      17,
                    ),
                    width: getHorizontalSize(
                      22,
                    ),
                    margin: getMargin(
                      top: 8,
                    ),
                    decoration: BoxDecoration(
                      color: ColorConstant.whiteA700,
                      borderRadius: BorderRadius.circular(
                        getHorizontalSize(
                          11,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: getPadding(
                left: 12,
                top: 12,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Padding(
                    padding: getPadding(
                      left: 5,
                    ),
                    child: Text(
                      listrectangle11ItemModelObj.nameTxt,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtInterRegular14,
                    ),
                  ),
                  Padding(
                    padding: getPadding(
                      top: 1,
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CustomImageView(
                          imagePath: ImageConstant.imgImage17,
                          height: getVerticalSize(
                            14,
                          ),
                          width: getHorizontalSize(
                            85,
                          ),
                          margin: getMargin(
                            bottom: 7,
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 113,
                            top: 9,
                          ),
                          child: Text(
                            listrectangle11ItemModelObj.locationTxt,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterRegular10,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
