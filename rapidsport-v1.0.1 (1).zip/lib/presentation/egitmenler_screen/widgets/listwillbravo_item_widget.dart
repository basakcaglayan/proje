import '../models/listwillbravo_item_model.dart';
import 'package:flutter/material.dart';
import 'package:rapidsport/core/app_export.dart';

// ignore: must_be_immutable
class ListwillbravoItemWidget extends StatelessWidget {
  ListwillbravoItemWidget(this.listwillbravoItemModelObj);

  ListwillbravoItemModel listwillbravoItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: getPadding(
        left: 8,
        top: 3,
        right: 8,
        bottom: 3,
      ),
      decoration: AppDecoration.outlineBlack900143.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder5,
      ),
      child: Row(
        children: [
          Container(
            margin: getMargin(
              top: 4,
              bottom: 5,
            ),
            decoration: AppDecoration.outlineBlack9003f,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Container(
                  height: getVerticalSize(
                    17,
                  ),
                  width: getHorizontalSize(
                    22,
                  ),
                  margin: getMargin(
                    top: 8,
                  ),
                  decoration: BoxDecoration(
                    color: ColorConstant.whiteA700,
                    borderRadius: BorderRadius.circular(
                      getHorizontalSize(
                        11,
                      ),
                    ),
                  ),
                ),
                CustomImageView(
                  svgPath: ImageConstant.imgSave,
                  height: getVerticalSize(
                    18,
                  ),
                  width: getHorizontalSize(
                    44,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: getPadding(
                left: 12,
                top: 10,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text(
                    listwillbravoItemModelObj.nameTxt,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.left,
                    style: AppStyle.txtInterRegular14,
                  ),
                  Padding(
                    padding: getPadding(
                      top: 3,
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CustomImageView(
                          imagePath: ImageConstant.imgImage17,
                          height: getVerticalSize(
                            14,
                          ),
                          width: getHorizontalSize(
                            85,
                          ),
                          margin: getMargin(
                            bottom: 7,
                          ),
                        ),
                        Padding(
                          padding: getPadding(
                            left: 110,
                            top: 9,
                          ),
                          child: Text(
                            listwillbravoItemModelObj.locationTxt,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtInterRegular10,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
