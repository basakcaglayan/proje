// ignore_for_file: must_be_immutable

part of 'egitmenler_bloc.dart';

@immutable
abstract class EgitmenlerEvent extends Equatable {}

class EgitmenlerInitialEvent extends EgitmenlerEvent {
  @override
  List<Object?> get props => [];
}
