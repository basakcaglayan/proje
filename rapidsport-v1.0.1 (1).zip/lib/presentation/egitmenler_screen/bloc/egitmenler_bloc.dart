import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import '../models/listrectangle11_item_model.dart';import '../models/listwillbravo_item_model.dart';import 'package:rapidsport/presentation/egitmenler_screen/models/egitmenler_model.dart';part 'egitmenler_event.dart';part 'egitmenler_state.dart';class EgitmenlerBloc extends Bloc<EgitmenlerEvent, EgitmenlerState> {EgitmenlerBloc(EgitmenlerState initialState) : super(initialState) { on<EgitmenlerInitialEvent>(_onInitialize); }

List<Listrectangle11ItemModel> fillListrectangle11ItemList() { return List.generate(3, (index) => Listrectangle11ItemModel()); } 
List<ListwillbravoItemModel> fillListwillbravoItemList() { return List.generate(4, (index) => ListwillbravoItemModel()); } 
_onInitialize(EgitmenlerInitialEvent event, Emitter<EgitmenlerState> emit, ) async  { emit(state.copyWith(searchController: TextEditingController())); emit(state.copyWith(egitmenlerModelObj: state.egitmenlerModelObj?.copyWith(listrectangle11ItemList: fillListrectangle11ItemList(), listwillbravoItemList: fillListwillbravoItemList()))); } 
 }
