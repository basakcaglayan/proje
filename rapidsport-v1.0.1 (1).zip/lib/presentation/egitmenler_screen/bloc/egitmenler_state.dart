// ignore_for_file: must_be_immutable

part of 'egitmenler_bloc.dart';

class EgitmenlerState extends Equatable {
  EgitmenlerState({
    this.searchController,
    this.egitmenlerModelObj,
  });

  TextEditingController? searchController;

  EgitmenlerModel? egitmenlerModelObj;

  @override
  List<Object?> get props => [
        searchController,
        egitmenlerModelObj,
      ];
  EgitmenlerState copyWith({
    TextEditingController? searchController,
    EgitmenlerModel? egitmenlerModelObj,
  }) {
    return EgitmenlerState(
      searchController: searchController ?? this.searchController,
      egitmenlerModelObj: egitmenlerModelObj ?? this.egitmenlerModelObj,
    );
  }
}
