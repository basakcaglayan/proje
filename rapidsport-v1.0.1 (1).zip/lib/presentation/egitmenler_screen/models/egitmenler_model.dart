import 'package:equatable/equatable.dart';import 'listrectangle11_item_model.dart';import 'listwillbravo_item_model.dart';
// ignore: must_be_immutable
class EgitmenlerModel extends Equatable {EgitmenlerModel({this.listrectangle11ItemList = const [], this.listwillbravoItemList = const []});

List<Listrectangle11ItemModel> listrectangle11ItemList;

List<ListwillbravoItemModel> listwillbravoItemList;

EgitmenlerModel copyWith({List<Listrectangle11ItemModel>? listrectangle11ItemList, List<ListwillbravoItemModel>? listwillbravoItemList}) { return EgitmenlerModel(
listrectangle11ItemList : listrectangle11ItemList ?? this.listrectangle11ItemList,
listwillbravoItemList : listwillbravoItemList ?? this.listwillbravoItemList,
); } 
@override List<Object?> get props => [listrectangle11ItemList,listwillbravoItemList];
 }
