class ListwillbravoItemModel {String nameTxt = "Kelsey Redmond";

String locationTxt = "BOSTANCI";

String? id = "";

 }
