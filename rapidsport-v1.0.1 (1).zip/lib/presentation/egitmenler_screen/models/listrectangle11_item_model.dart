class Listrectangle11ItemModel {String nameTxt = "Julie Capozziello";

String locationTxt = "MALTEPE";

String? id = "";

 }
