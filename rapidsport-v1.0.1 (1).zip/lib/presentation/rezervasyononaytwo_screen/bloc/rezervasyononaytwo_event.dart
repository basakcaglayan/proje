// ignore_for_file: must_be_immutable

part of 'rezervasyononaytwo_bloc.dart';

@immutable
abstract class RezervasyononaytwoEvent extends Equatable {}

class RezervasyononaytwoInitialEvent extends RezervasyononaytwoEvent {
  @override
  List<Object?> get props => [];
}
