import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:rapidsport/presentation/rezervasyononaytwo_screen/models/rezervasyononaytwo_model.dart';
part 'rezervasyononaytwo_event.dart';
part 'rezervasyononaytwo_state.dart';

class RezervasyononaytwoBloc
    extends Bloc<RezervasyononaytwoEvent, RezervasyononaytwoState> {
  RezervasyononaytwoBloc(RezervasyononaytwoState initialState)
      : super(initialState) {
    on<RezervasyononaytwoInitialEvent>(_onInitialize);
  }

  _onInitialize(
    RezervasyononaytwoInitialEvent event,
    Emitter<RezervasyononaytwoState> emit,
  ) async {}
}
