import 'bloc/rezervasyononaytwo_bloc.dart';
import 'models/rezervasyononaytwo_model.dart';
import 'package:flutter/material.dart';
import 'package:rapidsport/core/app_export.dart';

class RezervasyononaytwoScreen extends StatelessWidget {
  static Widget builder(BuildContext context) {
    return BlocProvider<RezervasyononaytwoBloc>(
      create: (context) => RezervasyononaytwoBloc(RezervasyononaytwoState(
        rezervasyononaytwoModelObj: RezervasyononaytwoModel(),
      ))
        ..add(RezervasyononaytwoInitialEvent()),
      child: RezervasyononaytwoScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<RezervasyononaytwoBloc, RezervasyononaytwoState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: Container(
              width: getHorizontalSize(
                375,
              ),
              padding: getPadding(
                left: 2,
                top: 48,
                right: 2,
                bottom: 48,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgHome1,
                    height: getSize(
                      48,
                    ),
                    width: getSize(
                      48,
                    ),
                    alignment: Alignment.centerRight,
                    margin: getMargin(
                      right: 16,
                    ),
                  ),
                  Container(
                    width: getHorizontalSize(
                      361,
                    ),
                    margin: getMargin(
                      left: 8,
                      top: 83,
                    ),
                    decoration: AppDecoration.txtOutlineBlack9003f,
                    child: Text(
                      "msg_rezervasyonunuz".tr,
                      maxLines: null,
                      textAlign: TextAlign.center,
                      style: AppStyle.txtInterRegular34,
                    ),
                  ),
                  CustomImageView(
                    imagePath: ImageConstant.imgCorrect2,
                    height: getSize(
                      123,
                    ),
                    width: getSize(
                      123,
                    ),
                    margin: getMargin(
                      top: 4,
                    ),
                  ),
                  Container(
                    width: getHorizontalSize(
                      252,
                    ),
                    margin: getMargin(
                      top: 16,
                      bottom: 5,
                    ),
                    child: Text(
                      "msg_yi_antrenmanlar".tr,
                      maxLines: null,
                      textAlign: TextAlign.center,
                      style: AppStyle.txtInterRegular34,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
