import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class RezervasyononaytwoModel extends Equatable {RezervasyononaytwoModel copyWith() { return RezervasyononaytwoModel(
); } 
@override List<Object?> get props => [];
 }
