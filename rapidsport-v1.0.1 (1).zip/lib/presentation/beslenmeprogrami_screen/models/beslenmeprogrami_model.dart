import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class BeslenmeprogramiModel extends Equatable {BeslenmeprogramiModel copyWith() { return BeslenmeprogramiModel(
); } 
@override List<Object?> get props => [];
 }
