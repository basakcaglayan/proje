// ignore_for_file: must_be_immutable

part of 'beslenmeprogrami_bloc.dart';

class BeslenmeprogramiState extends Equatable {
  BeslenmeprogramiState({this.beslenmeprogramiModelObj});

  BeslenmeprogramiModel? beslenmeprogramiModelObj;

  @override
  List<Object?> get props => [
        beslenmeprogramiModelObj,
      ];
  BeslenmeprogramiState copyWith(
      {BeslenmeprogramiModel? beslenmeprogramiModelObj}) {
    return BeslenmeprogramiState(
      beslenmeprogramiModelObj:
          beslenmeprogramiModelObj ?? this.beslenmeprogramiModelObj,
    );
  }
}
