// ignore_for_file: must_be_immutable

part of 'beslenmeprogrami_bloc.dart';

@immutable
abstract class BeslenmeprogramiEvent extends Equatable {}

class BeslenmeprogramiInitialEvent extends BeslenmeprogramiEvent {
  @override
  List<Object?> get props => [];
}
