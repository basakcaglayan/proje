import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/beslenmeprogrami_screen/models/beslenmeprogrami_model.dart';part 'beslenmeprogrami_event.dart';part 'beslenmeprogrami_state.dart';class BeslenmeprogramiBloc extends Bloc<BeslenmeprogramiEvent, BeslenmeprogramiState> {BeslenmeprogramiBloc(BeslenmeprogramiState initialState) : super(initialState) { on<BeslenmeprogramiInitialEvent>(_onInitialize); }

_onInitialize(BeslenmeprogramiInitialEvent event, Emitter<BeslenmeprogramiState> emit, ) async  {  } 
 }
