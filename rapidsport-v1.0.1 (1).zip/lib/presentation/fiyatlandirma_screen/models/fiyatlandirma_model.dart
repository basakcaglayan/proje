import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class FiyatlandirmaModel extends Equatable {FiyatlandirmaModel copyWith() { return FiyatlandirmaModel(
); } 
@override List<Object?> get props => [];
 }
