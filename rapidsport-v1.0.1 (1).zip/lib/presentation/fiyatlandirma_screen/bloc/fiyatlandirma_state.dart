// ignore_for_file: must_be_immutable

part of 'fiyatlandirma_bloc.dart';

class FiyatlandirmaState extends Equatable {
  FiyatlandirmaState({this.fiyatlandirmaModelObj});

  FiyatlandirmaModel? fiyatlandirmaModelObj;

  @override
  List<Object?> get props => [
        fiyatlandirmaModelObj,
      ];
  FiyatlandirmaState copyWith({FiyatlandirmaModel? fiyatlandirmaModelObj}) {
    return FiyatlandirmaState(
      fiyatlandirmaModelObj:
          fiyatlandirmaModelObj ?? this.fiyatlandirmaModelObj,
    );
  }
}
