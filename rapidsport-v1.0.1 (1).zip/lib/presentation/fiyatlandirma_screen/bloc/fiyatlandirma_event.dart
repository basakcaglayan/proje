// ignore_for_file: must_be_immutable

part of 'fiyatlandirma_bloc.dart';

@immutable
abstract class FiyatlandirmaEvent extends Equatable {}

class FiyatlandirmaInitialEvent extends FiyatlandirmaEvent {
  @override
  List<Object?> get props => [];
}
