import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/fiyatlandirma_screen/models/fiyatlandirma_model.dart';part 'fiyatlandirma_event.dart';part 'fiyatlandirma_state.dart';class FiyatlandirmaBloc extends Bloc<FiyatlandirmaEvent, FiyatlandirmaState> {FiyatlandirmaBloc(FiyatlandirmaState initialState) : super(initialState) { on<FiyatlandirmaInitialEvent>(_onInitialize); }

_onInitialize(FiyatlandirmaInitialEvent event, Emitter<FiyatlandirmaState> emit, ) async  {  } 
 }
