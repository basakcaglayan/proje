import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/yakinantonay_screen/models/yakinantonay_model.dart';part 'yakinantonay_event.dart';part 'yakinantonay_state.dart';class YakinantonayBloc extends Bloc<YakinantonayEvent, YakinantonayState> {YakinantonayBloc(YakinantonayState initialState) : super(initialState) { on<YakinantonayInitialEvent>(_onInitialize); }

_onInitialize(YakinantonayInitialEvent event, Emitter<YakinantonayState> emit, ) async  {  } 
 }
