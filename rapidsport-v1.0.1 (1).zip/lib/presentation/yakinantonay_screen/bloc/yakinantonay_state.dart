// ignore_for_file: must_be_immutable

part of 'yakinantonay_bloc.dart';

class YakinantonayState extends Equatable {
  YakinantonayState({this.yakinantonayModelObj});

  YakinantonayModel? yakinantonayModelObj;

  @override
  List<Object?> get props => [
        yakinantonayModelObj,
      ];
  YakinantonayState copyWith({YakinantonayModel? yakinantonayModelObj}) {
    return YakinantonayState(
      yakinantonayModelObj: yakinantonayModelObj ?? this.yakinantonayModelObj,
    );
  }
}
