// ignore_for_file: must_be_immutable

part of 'yakinantonay_bloc.dart';

@immutable
abstract class YakinantonayEvent extends Equatable {}

class YakinantonayInitialEvent extends YakinantonayEvent {
  @override
  List<Object?> get props => [];
}
