import 'package:equatable/equatable.dart';import 'package:rapidsport/data/models/selectionPopupModel/selection_popup_model.dart';import 'listsu_item_model.dart';
// ignore: must_be_immutable
class RezervasyonolusturmaModel extends Equatable {RezervasyonolusturmaModel({this.dropdownItemList = const [], this.dropdownItemList1 = const [], this.listsuItemList = const []});

List<SelectionPopupModel> dropdownItemList;

List<SelectionPopupModel> dropdownItemList1;

List<ListsuItemModel> listsuItemList;

RezervasyonolusturmaModel copyWith({List<SelectionPopupModel>? dropdownItemList, List<SelectionPopupModel>? dropdownItemList1, List<ListsuItemModel>? listsuItemList}) { return RezervasyonolusturmaModel(
dropdownItemList : dropdownItemList ?? this.dropdownItemList,
dropdownItemList1 : dropdownItemList1 ?? this.dropdownItemList1,
listsuItemList : listsuItemList ?? this.listsuItemList,
); } 
@override List<Object?> get props => [dropdownItemList,dropdownItemList1,listsuItemList];
 }
