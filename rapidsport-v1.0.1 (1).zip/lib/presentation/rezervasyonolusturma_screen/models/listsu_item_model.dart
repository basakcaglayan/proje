class ListsuItemModel {String suTxt = "Mo";

String suoneTxt = "Tu";

String sutwoTxt = "We";

String suthreeTxt = "Th";

String sufourTxt = "Fri";

String sufiveTxt = "Sa";

String susixTxt = "Su";

String? id = "";

 }
