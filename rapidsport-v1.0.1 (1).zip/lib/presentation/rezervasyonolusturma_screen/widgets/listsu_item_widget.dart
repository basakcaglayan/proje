import '../models/listsu_item_model.dart';
import 'package:flutter/material.dart';
import 'package:rapidsport/core/app_export.dart';

// ignore: must_be_immutable
class ListsuItemWidget extends StatelessWidget {
  ListsuItemWidget(this.listsuItemModelObj);

  ListsuItemModel listsuItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          listsuItemModelObj.suTxt,
          overflow: TextOverflow.ellipsis,
          textAlign: TextAlign.left,
          style: AppStyle.txtInterSemiBold13,
        ),
        Padding(
          padding: getPadding(
            left: 18,
          ),
          child: Text(
            listsuItemModelObj.suoneTxt,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.left,
            style: AppStyle.txtInterSemiBold13,
          ),
        ),
        Padding(
          padding: getPadding(
            left: 18,
          ),
          child: Text(
            listsuItemModelObj.sutwoTxt,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.left,
            style: AppStyle.txtInterSemiBold13,
          ),
        ),
        Padding(
          padding: getPadding(
            left: 17,
          ),
          child: Text(
            listsuItemModelObj.suthreeTxt,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.left,
            style: AppStyle.txtInterSemiBold13,
          ),
        ),
        Padding(
          padding: getPadding(
            left: 20,
          ),
          child: Text(
            listsuItemModelObj.sufourTxt,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.left,
            style: AppStyle.txtInterSemiBold13,
          ),
        ),
        Padding(
          padding: getPadding(
            left: 20,
          ),
          child: Text(
            listsuItemModelObj.sufiveTxt,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.left,
            style: AppStyle.txtInterSemiBold13,
          ),
        ),
        Padding(
          padding: getPadding(
            left: 20,
          ),
          child: Text(
            listsuItemModelObj.susixTxt,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.left,
            style: AppStyle.txtInterSemiBold13,
          ),
        ),
      ],
    );
  }
}
