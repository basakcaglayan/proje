// ignore_for_file: must_be_immutable

part of 'rezervasyonolusturma_bloc.dart';

@immutable
abstract class RezervasyonolusturmaEvent extends Equatable {}

class RezervasyonolusturmaInitialEvent extends RezervasyonolusturmaEvent {
  @override
  List<Object?> get props => [];
}

///event for dropdown selection
class ChangeDropDownEvent extends RezervasyonolusturmaEvent {
  ChangeDropDownEvent({required this.value});

  SelectionPopupModel value;

  @override
  List<Object?> get props => [
        value,
      ];
}

///event for dropdown selection
class ChangeDropDown1Event extends RezervasyonolusturmaEvent {
  ChangeDropDown1Event({required this.value});

  SelectionPopupModel value;

  @override
  List<Object?> get props => [
        value,
      ];
}
