// ignore_for_file: must_be_immutable

part of 'rezervasyonolusturma_bloc.dart';

class RezervasyonolusturmaState extends Equatable {
  RezervasyonolusturmaState({
    this.selectedDropDownValue,
    this.selectedDropDownValue1,
    this.rezervasyonolusturmaModelObj,
  });

  SelectionPopupModel? selectedDropDownValue;

  SelectionPopupModel? selectedDropDownValue1;

  RezervasyonolusturmaModel? rezervasyonolusturmaModelObj;

  @override
  List<Object?> get props => [
        selectedDropDownValue,
        selectedDropDownValue1,
        rezervasyonolusturmaModelObj,
      ];
  RezervasyonolusturmaState copyWith({
    SelectionPopupModel? selectedDropDownValue,
    SelectionPopupModel? selectedDropDownValue1,
    RezervasyonolusturmaModel? rezervasyonolusturmaModelObj,
  }) {
    return RezervasyonolusturmaState(
      selectedDropDownValue:
          selectedDropDownValue ?? this.selectedDropDownValue,
      selectedDropDownValue1:
          selectedDropDownValue1 ?? this.selectedDropDownValue1,
      rezervasyonolusturmaModelObj:
          rezervasyonolusturmaModelObj ?? this.rezervasyonolusturmaModelObj,
    );
  }
}
