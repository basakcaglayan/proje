// ignore_for_file: must_be_immutable

part of 'antrenmanprogramiprogram_bloc.dart';

class AntrenmanprogramiprogramState extends Equatable {
  AntrenmanprogramiprogramState({this.antrenmanprogramiprogramModelObj});

  AntrenmanprogramiprogramModel? antrenmanprogramiprogramModelObj;

  @override
  List<Object?> get props => [
        antrenmanprogramiprogramModelObj,
      ];
  AntrenmanprogramiprogramState copyWith(
      {AntrenmanprogramiprogramModel? antrenmanprogramiprogramModelObj}) {
    return AntrenmanprogramiprogramState(
      antrenmanprogramiprogramModelObj: antrenmanprogramiprogramModelObj ??
          this.antrenmanprogramiprogramModelObj,
    );
  }
}
