import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/antrenmanprogramiprogram_screen/models/antrenmanprogramiprogram_model.dart';part 'antrenmanprogramiprogram_event.dart';part 'antrenmanprogramiprogram_state.dart';class AntrenmanprogramiprogramBloc extends Bloc<AntrenmanprogramiprogramEvent, AntrenmanprogramiprogramState> {AntrenmanprogramiprogramBloc(AntrenmanprogramiprogramState initialState) : super(initialState) { on<AntrenmanprogramiprogramInitialEvent>(_onInitialize); }

_onInitialize(AntrenmanprogramiprogramInitialEvent event, Emitter<AntrenmanprogramiprogramState> emit, ) async  {  } 
 }
