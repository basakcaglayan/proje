// ignore_for_file: must_be_immutable

part of 'antrenmanprogramiprogram_bloc.dart';

@immutable
abstract class AntrenmanprogramiprogramEvent extends Equatable {}

class AntrenmanprogramiprogramInitialEvent
    extends AntrenmanprogramiprogramEvent {
  @override
  List<Object?> get props => [];
}
