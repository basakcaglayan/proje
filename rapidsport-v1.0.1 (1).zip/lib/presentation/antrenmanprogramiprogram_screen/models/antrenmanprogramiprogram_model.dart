import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class AntrenmanprogramiprogramModel extends Equatable {AntrenmanprogramiprogramModel copyWith() { return AntrenmanprogramiprogramModel(
); } 
@override List<Object?> get props => [];
 }
