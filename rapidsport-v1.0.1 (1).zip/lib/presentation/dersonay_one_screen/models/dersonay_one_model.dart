import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class DersonayOneModel extends Equatable {DersonayOneModel copyWith() { return DersonayOneModel(
); } 
@override List<Object?> get props => [];
 }
