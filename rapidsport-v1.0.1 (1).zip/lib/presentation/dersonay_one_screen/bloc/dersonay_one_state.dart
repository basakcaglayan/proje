// ignore_for_file: must_be_immutable

part of 'dersonay_one_bloc.dart';

class DersonayOneState extends Equatable {
  DersonayOneState({this.dersonayOneModelObj});

  DersonayOneModel? dersonayOneModelObj;

  @override
  List<Object?> get props => [
        dersonayOneModelObj,
      ];
  DersonayOneState copyWith({DersonayOneModel? dersonayOneModelObj}) {
    return DersonayOneState(
      dersonayOneModelObj: dersonayOneModelObj ?? this.dersonayOneModelObj,
    );
  }
}
