// ignore_for_file: must_be_immutable

part of 'dersonay_one_bloc.dart';

@immutable
abstract class DersonayOneEvent extends Equatable {}

class DersonayOneInitialEvent extends DersonayOneEvent {
  @override
  List<Object?> get props => [];
}
