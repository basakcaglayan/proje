import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/dersonay_one_screen/models/dersonay_one_model.dart';part 'dersonay_one_event.dart';part 'dersonay_one_state.dart';class DersonayOneBloc extends Bloc<DersonayOneEvent, DersonayOneState> {DersonayOneBloc(DersonayOneState initialState) : super(initialState) { on<DersonayOneInitialEvent>(_onInitialize); }

_onInitialize(DersonayOneInitialEvent event, Emitter<DersonayOneState> emit, ) async  {  } 
 }
