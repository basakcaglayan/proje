import '../models/dersrezerveet_item_model.dart';
import 'package:flutter/material.dart';
import 'package:rapidsport/core/app_export.dart';

// ignore: must_be_immutable
class DersrezerveetItemWidget extends StatelessWidget {
  DersrezerveetItemWidget(this.dersrezerveetItemModelObj,
      {this.onTapColumntennisone});

  DersrezerveetItemModel dersrezerveetItemModelObj;

  VoidCallback? onTapColumntennisone;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        onTapColumntennisone?.call();
      },
      child: Container(
        padding: getPadding(
          left: 27,
          top: 13,
          right: 27,
          bottom: 13,
        ),
        decoration: AppDecoration.fillTeal7001e.copyWith(
          borderRadius: BorderRadiusStyle.roundedBorder51,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CustomImageView(
              imagePath: ImageConstant.imgTennis1,
              height: getVerticalSize(
                53,
              ),
              width: getHorizontalSize(
                45,
              ),
              alignment: Alignment.centerRight,
            ),
            Padding(
              padding: getPadding(
                top: 1,
                bottom: 3,
              ),
              child: Text(
                dersrezerveetItemModelObj.typeTxt,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.left,
                style: AppStyle.txtABeeZeeRegular16,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
