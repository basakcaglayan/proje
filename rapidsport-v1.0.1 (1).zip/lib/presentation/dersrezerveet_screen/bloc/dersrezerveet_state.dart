// ignore_for_file: must_be_immutable

part of 'dersrezerveet_bloc.dart';

class DersrezerveetState extends Equatable {
  DersrezerveetState({
    this.searchController,
    this.dersrezerveetModelObj,
  });

  TextEditingController? searchController;

  DersrezerveetModel? dersrezerveetModelObj;

  @override
  List<Object?> get props => [
        searchController,
        dersrezerveetModelObj,
      ];
  DersrezerveetState copyWith({
    TextEditingController? searchController,
    DersrezerveetModel? dersrezerveetModelObj,
  }) {
    return DersrezerveetState(
      searchController: searchController ?? this.searchController,
      dersrezerveetModelObj:
          dersrezerveetModelObj ?? this.dersrezerveetModelObj,
    );
  }
}
