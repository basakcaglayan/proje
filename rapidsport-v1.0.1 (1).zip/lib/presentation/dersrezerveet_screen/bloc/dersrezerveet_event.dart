// ignore_for_file: must_be_immutable

part of 'dersrezerveet_bloc.dart';

@immutable
abstract class DersrezerveetEvent extends Equatable {}

class DersrezerveetInitialEvent extends DersrezerveetEvent {
  @override
  List<Object?> get props => [];
}
