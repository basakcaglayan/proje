import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import '../models/dersrezerveet_item_model.dart';import 'package:rapidsport/presentation/dersrezerveet_screen/models/dersrezerveet_model.dart';part 'dersrezerveet_event.dart';part 'dersrezerveet_state.dart';class DersrezerveetBloc extends Bloc<DersrezerveetEvent, DersrezerveetState> {DersrezerveetBloc(DersrezerveetState initialState) : super(initialState) { on<DersrezerveetInitialEvent>(_onInitialize); }

List<DersrezerveetItemModel> fillDersrezerveetItemList() { return List.generate(11, (index) => DersrezerveetItemModel()); } 
_onInitialize(DersrezerveetInitialEvent event, Emitter<DersrezerveetState> emit, ) async  { emit(state.copyWith(searchController: TextEditingController())); emit(state.copyWith(dersrezerveetModelObj: state.dersrezerveetModelObj?.copyWith(dersrezerveetItemList: fillDersrezerveetItemList()))); } 
 }
