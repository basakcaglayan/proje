class DersrezerveetItemModel {String typeTxt = "Tenis";

String? id = "";

 }
