import 'package:equatable/equatable.dart';import 'dersrezerveet_item_model.dart';
// ignore: must_be_immutable
class DersrezerveetModel extends Equatable {DersrezerveetModel({this.dersrezerveetItemList = const []});

List<DersrezerveetItemModel> dersrezerveetItemList;

DersrezerveetModel copyWith({List<DersrezerveetItemModel>? dersrezerveetItemList}) { return DersrezerveetModel(
dersrezerveetItemList : dersrezerveetItemList ?? this.dersrezerveetItemList,
); } 
@override List<Object?> get props => [dersrezerveetItemList];
 }
