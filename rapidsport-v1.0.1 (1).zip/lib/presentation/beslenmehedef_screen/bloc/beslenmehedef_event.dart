// ignore_for_file: must_be_immutable

part of 'beslenmehedef_bloc.dart';

@immutable
abstract class BeslenmehedefEvent extends Equatable {}

class BeslenmehedefInitialEvent extends BeslenmehedefEvent {
  @override
  List<Object?> get props => [];
}
