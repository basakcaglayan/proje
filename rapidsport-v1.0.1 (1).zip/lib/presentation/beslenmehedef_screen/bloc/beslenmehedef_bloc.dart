import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/beslenmehedef_screen/models/beslenmehedef_model.dart';part 'beslenmehedef_event.dart';part 'beslenmehedef_state.dart';class BeslenmehedefBloc extends Bloc<BeslenmehedefEvent, BeslenmehedefState> {BeslenmehedefBloc(BeslenmehedefState initialState) : super(initialState) { on<BeslenmehedefInitialEvent>(_onInitialize); }

_onInitialize(BeslenmehedefInitialEvent event, Emitter<BeslenmehedefState> emit, ) async  {  } 
 }
