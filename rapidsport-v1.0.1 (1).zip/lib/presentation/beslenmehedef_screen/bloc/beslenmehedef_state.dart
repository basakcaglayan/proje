// ignore_for_file: must_be_immutable

part of 'beslenmehedef_bloc.dart';

class BeslenmehedefState extends Equatable {
  BeslenmehedefState({this.beslenmehedefModelObj});

  BeslenmehedefModel? beslenmehedefModelObj;

  @override
  List<Object?> get props => [
        beslenmehedefModelObj,
      ];
  BeslenmehedefState copyWith({BeslenmehedefModel? beslenmehedefModelObj}) {
    return BeslenmehedefState(
      beslenmehedefModelObj:
          beslenmehedefModelObj ?? this.beslenmehedefModelObj,
    );
  }
}
