import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class BeslenmehedefModel extends Equatable {BeslenmehedefModel copyWith() { return BeslenmehedefModel(
); } 
@override List<Object?> get props => [];
 }
