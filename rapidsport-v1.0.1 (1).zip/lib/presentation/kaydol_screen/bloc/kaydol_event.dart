// ignore_for_file: must_be_immutable

part of 'kaydol_bloc.dart';

@immutable
abstract class KaydolEvent extends Equatable {}

class KaydolInitialEvent extends KaydolEvent {
  @override
  List<Object?> get props => [];
}
