import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/kaydol_screen/models/kaydol_model.dart';part 'kaydol_event.dart';part 'kaydol_state.dart';class KaydolBloc extends Bloc<KaydolEvent, KaydolState> {KaydolBloc(KaydolState initialState) : super(initialState) { on<KaydolInitialEvent>(_onInitialize); }

_onInitialize(KaydolInitialEvent event, Emitter<KaydolState> emit, ) async  { emit(state.copyWith(nameController: TextEditingController(), nameoneController: TextEditingController(), nametwoController: TextEditingController())); } 
 }
