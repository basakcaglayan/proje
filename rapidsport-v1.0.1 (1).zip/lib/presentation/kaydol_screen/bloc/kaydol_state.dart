// ignore_for_file: must_be_immutable

part of 'kaydol_bloc.dart';

class KaydolState extends Equatable {
  KaydolState({
    this.nameController,
    this.nameoneController,
    this.nametwoController,
    this.kaydolModelObj,
  });

  TextEditingController? nameController;

  TextEditingController? nameoneController;

  TextEditingController? nametwoController;

  KaydolModel? kaydolModelObj;

  @override
  List<Object?> get props => [
        nameController,
        nameoneController,
        nametwoController,
        kaydolModelObj,
      ];
  KaydolState copyWith({
    TextEditingController? nameController,
    TextEditingController? nameoneController,
    TextEditingController? nametwoController,
    KaydolModel? kaydolModelObj,
  }) {
    return KaydolState(
      nameController: nameController ?? this.nameController,
      nameoneController: nameoneController ?? this.nameoneController,
      nametwoController: nametwoController ?? this.nametwoController,
      kaydolModelObj: kaydolModelObj ?? this.kaydolModelObj,
    );
  }
}
