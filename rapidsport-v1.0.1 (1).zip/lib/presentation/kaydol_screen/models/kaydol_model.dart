import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class KaydolModel extends Equatable {KaydolModel copyWith() { return KaydolModel(
); } 
@override List<Object?> get props => [];
 }
