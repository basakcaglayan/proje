// ignore_for_file: must_be_immutable

part of 'antrenmansure_bloc.dart';

class AntrenmansureState extends Equatable {
  AntrenmansureState({this.antrenmansureModelObj});

  AntrenmansureModel? antrenmansureModelObj;

  @override
  List<Object?> get props => [
        antrenmansureModelObj,
      ];
  AntrenmansureState copyWith({AntrenmansureModel? antrenmansureModelObj}) {
    return AntrenmansureState(
      antrenmansureModelObj:
          antrenmansureModelObj ?? this.antrenmansureModelObj,
    );
  }
}
