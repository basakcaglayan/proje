// ignore_for_file: must_be_immutable

part of 'antrenmansure_bloc.dart';

@immutable
abstract class AntrenmansureEvent extends Equatable {}

class AntrenmansureInitialEvent extends AntrenmansureEvent {
  @override
  List<Object?> get props => [];
}
