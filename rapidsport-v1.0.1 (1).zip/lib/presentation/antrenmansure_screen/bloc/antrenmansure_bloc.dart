import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/antrenmansure_screen/models/antrenmansure_model.dart';part 'antrenmansure_event.dart';part 'antrenmansure_state.dart';class AntrenmansureBloc extends Bloc<AntrenmansureEvent, AntrenmansureState> {AntrenmansureBloc(AntrenmansureState initialState) : super(initialState) { on<AntrenmansureInitialEvent>(_onInitialize); }

_onInitialize(AntrenmansureInitialEvent event, Emitter<AntrenmansureState> emit, ) async  {  } 
 }
