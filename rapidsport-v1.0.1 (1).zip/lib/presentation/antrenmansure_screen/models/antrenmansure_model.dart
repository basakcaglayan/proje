import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class AntrenmansureModel extends Equatable {AntrenmansureModel copyWith() { return AntrenmansureModel(
); } 
@override List<Object?> get props => [];
 }
