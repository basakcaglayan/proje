import '../models/ayarlar_one_item_model.dart';
import 'package:flutter/material.dart';
import 'package:rapidsport/core/app_export.dart';

// ignore: must_be_immutable
class AyarlarOneItemWidget extends StatelessWidget {
  AyarlarOneItemWidget(this.ayarlarOneItemModelObj);

  AyarlarOneItemModel ayarlarOneItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: Container(
        width: double.maxFinite,
        child: Container(
          decoration: AppDecoration.outlineBlack900143.copyWith(
            borderRadius: BorderRadiusStyle.roundedBorder5,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                padding: getPadding(
                  left: 8,
                  top: 4,
                  right: 8,
                  bottom: 4,
                ),
                decoration: AppDecoration.outlineBlack900143.copyWith(
                  borderRadius: BorderRadiusStyle.roundedBorder5,
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: getMargin(
                        top: 3,
                        bottom: 4,
                      ),
                      decoration: AppDecoration.outlineBlack9003f,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Container(
                            height: getVerticalSize(
                              16,
                            ),
                            width: getHorizontalSize(
                              21,
                            ),
                            margin: getMargin(
                              top: 8,
                            ),
                            decoration: BoxDecoration(
                              color: ColorConstant.whiteA700,
                              borderRadius: BorderRadius.circular(
                                getHorizontalSize(
                                  10,
                                ),
                              ),
                            ),
                          ),
                          CustomImageView(
                            svgPath: ImageConstant.imgSave,
                            height: getVerticalSize(
                              16,
                            ),
                            width: getHorizontalSize(
                              43,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: getPadding(
                        left: 8,
                        bottom: 5,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Padding(
                            padding: getPadding(
                              left: 1,
                            ),
                            child: Text(
                              ayarlarOneItemModelObj.nameTxt,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterRegular12,
                            ),
                          ),
                          CustomImageView(
                            imagePath: ImageConstant.imgImage17,
                            height: getVerticalSize(
                              10,
                            ),
                            width: getHorizontalSize(
                              45,
                            ),
                            margin: getMargin(
                              top: 1,
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              top: 2,
                            ),
                            child: Text(
                              ayarlarOneItemModelObj.commentTxt,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterRegular10,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
