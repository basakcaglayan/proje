// ignore_for_file: must_be_immutable

part of 'ayarlar_one_bloc.dart';

@immutable
abstract class AyarlarOneEvent extends Equatable {}

class AyarlarOneInitialEvent extends AyarlarOneEvent {
  @override
  List<Object?> get props => [];
}
