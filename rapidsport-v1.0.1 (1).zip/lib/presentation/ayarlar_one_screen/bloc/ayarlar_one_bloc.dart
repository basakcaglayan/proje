import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import '../models/ayarlar_one_item_model.dart';import 'package:rapidsport/presentation/ayarlar_one_screen/models/ayarlar_one_model.dart';part 'ayarlar_one_event.dart';part 'ayarlar_one_state.dart';class AyarlarOneBloc extends Bloc<AyarlarOneEvent, AyarlarOneState> {AyarlarOneBloc(AyarlarOneState initialState) : super(initialState) { on<AyarlarOneInitialEvent>(_onInitialize); }

_onInitialize(AyarlarOneInitialEvent event, Emitter<AyarlarOneState> emit, ) async  { emit(state.copyWith(ayarlarOneModelObj: state.ayarlarOneModelObj?.copyWith(ayarlarOneItemList: fillAyarlarOneItemList()))); } 
List<AyarlarOneItemModel> fillAyarlarOneItemList() { return List.generate(2, (index) => AyarlarOneItemModel()); } 
 }
