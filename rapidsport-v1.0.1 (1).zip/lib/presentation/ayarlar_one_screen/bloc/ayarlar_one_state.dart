// ignore_for_file: must_be_immutable

part of 'ayarlar_one_bloc.dart';

class AyarlarOneState extends Equatable {
  AyarlarOneState({this.ayarlarOneModelObj});

  AyarlarOneModel? ayarlarOneModelObj;

  @override
  List<Object?> get props => [
        ayarlarOneModelObj,
      ];
  AyarlarOneState copyWith({AyarlarOneModel? ayarlarOneModelObj}) {
    return AyarlarOneState(
      ayarlarOneModelObj: ayarlarOneModelObj ?? this.ayarlarOneModelObj,
    );
  }
}
