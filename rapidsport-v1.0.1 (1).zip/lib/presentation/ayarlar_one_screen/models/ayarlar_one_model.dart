import 'package:equatable/equatable.dart';import 'ayarlar_one_item_model.dart';
// ignore: must_be_immutable
class AyarlarOneModel extends Equatable {AyarlarOneModel({this.ayarlarOneItemList = const []});

List<AyarlarOneItemModel> ayarlarOneItemList;

AyarlarOneModel copyWith({List<AyarlarOneItemModel>? ayarlarOneItemList}) { return AyarlarOneModel(
ayarlarOneItemList : ayarlarOneItemList ?? this.ayarlarOneItemList,
); } 
@override List<Object?> get props => [ayarlarOneItemList];
 }
