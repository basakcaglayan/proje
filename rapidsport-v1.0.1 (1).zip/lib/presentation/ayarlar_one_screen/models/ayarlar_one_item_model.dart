class AyarlarOneItemModel {String nameTxt = "Dontrell Britton";

String commentTxt = "Çok keyifli bir dersti.";

String? id = "";

 }
