import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class RezervasyononaytwoTwoModel extends Equatable {RezervasyononaytwoTwoModel copyWith() { return RezervasyononaytwoTwoModel(
); } 
@override List<Object?> get props => [];
 }
