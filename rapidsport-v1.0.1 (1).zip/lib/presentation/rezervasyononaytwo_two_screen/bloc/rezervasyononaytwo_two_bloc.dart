import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:rapidsport/presentation/rezervasyononaytwo_two_screen/models/rezervasyononaytwo_two_model.dart';
part 'rezervasyononaytwo_two_event.dart';
part 'rezervasyononaytwo_two_state.dart';

class RezervasyononaytwoTwoBloc
    extends Bloc<RezervasyononaytwoTwoEvent, RezervasyononaytwoTwoState> {
  RezervasyononaytwoTwoBloc(RezervasyononaytwoTwoState initialState)
      : super(initialState) {
    on<RezervasyononaytwoTwoInitialEvent>(_onInitialize);
  }

  _onInitialize(
    RezervasyononaytwoTwoInitialEvent event,
    Emitter<RezervasyononaytwoTwoState> emit,
  ) async {}
}
