// ignore_for_file: must_be_immutable

part of 'rezervasyononaytwo_two_bloc.dart';

class RezervasyononaytwoTwoState extends Equatable {
  RezervasyononaytwoTwoState({this.rezervasyononaytwoTwoModelObj});

  RezervasyononaytwoTwoModel? rezervasyononaytwoTwoModelObj;

  @override
  List<Object?> get props => [
        rezervasyononaytwoTwoModelObj,
      ];
  RezervasyononaytwoTwoState copyWith(
      {RezervasyononaytwoTwoModel? rezervasyononaytwoTwoModelObj}) {
    return RezervasyononaytwoTwoState(
      rezervasyononaytwoTwoModelObj:
          rezervasyononaytwoTwoModelObj ?? this.rezervasyononaytwoTwoModelObj,
    );
  }
}
