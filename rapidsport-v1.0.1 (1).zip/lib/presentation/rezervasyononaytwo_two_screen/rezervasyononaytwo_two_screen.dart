import 'bloc/rezervasyononaytwo_two_bloc.dart';
import 'models/rezervasyononaytwo_two_model.dart';
import 'package:flutter/material.dart';
import 'package:rapidsport/core/app_export.dart';

class RezervasyononaytwoTwoScreen extends StatelessWidget {
  static Widget builder(BuildContext context) {
    return BlocProvider<RezervasyononaytwoTwoBloc>(
      create: (context) => RezervasyononaytwoTwoBloc(RezervasyononaytwoTwoState(
        rezervasyononaytwoTwoModelObj: RezervasyononaytwoTwoModel(),
      ))
        ..add(RezervasyononaytwoTwoInitialEvent()),
      child: RezervasyononaytwoTwoScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<RezervasyononaytwoTwoBloc, RezervasyononaytwoTwoState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: Container(
              width: getHorizontalSize(
                375,
              ),
              padding: getPadding(
                left: 2,
                top: 48,
                right: 2,
                bottom: 48,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgHome1,
                    height: getSize(
                      48,
                    ),
                    width: getSize(
                      48,
                    ),
                    alignment: Alignment.centerRight,
                    margin: getMargin(
                      right: 16,
                    ),
                  ),
                  Container(
                    width: getHorizontalSize(
                      359,
                    ),
                    margin: getMargin(
                      left: 9,
                      top: 76,
                    ),
                    decoration: AppDecoration.txtOutlineBlack9003f,
                    child: Text(
                      "msg_rezervasyon_ste".tr,
                      maxLines: null,
                      textAlign: TextAlign.center,
                      style: AppStyle.txtInterRegular34,
                    ),
                  ),
                  CustomImageView(
                    imagePath: ImageConstant.imgDelete1,
                    height: getVerticalSize(
                      157,
                    ),
                    width: getHorizontalSize(
                      155,
                    ),
                    margin: getMargin(
                      top: 40,
                    ),
                  ),
                  Container(
                    width: getHorizontalSize(
                      335,
                    ),
                    margin: getMargin(
                      left: 18,
                      top: 39,
                      right: 15,
                      bottom: 5,
                    ),
                    child: Text(
                      "msg_sonraki_antrenmanlar".tr,
                      maxLines: null,
                      textAlign: TextAlign.center,
                      style: AppStyle.txtInterRegular34,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
