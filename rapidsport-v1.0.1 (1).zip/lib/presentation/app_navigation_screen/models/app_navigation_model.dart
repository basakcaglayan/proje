import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class AppNavigationModel extends Equatable {AppNavigationModel copyWith() { return AppNavigationModel(
); } 
@override List<Object?> get props => [];
 }
