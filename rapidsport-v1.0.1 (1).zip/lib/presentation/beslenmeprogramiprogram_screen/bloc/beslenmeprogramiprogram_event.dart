// ignore_for_file: must_be_immutable

part of 'beslenmeprogramiprogram_bloc.dart';

@immutable
abstract class BeslenmeprogramiprogramEvent extends Equatable {}

class BeslenmeprogramiprogramInitialEvent extends BeslenmeprogramiprogramEvent {
  @override
  List<Object?> get props => [];
}
