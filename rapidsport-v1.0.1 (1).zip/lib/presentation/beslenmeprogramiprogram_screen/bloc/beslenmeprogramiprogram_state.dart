// ignore_for_file: must_be_immutable

part of 'beslenmeprogramiprogram_bloc.dart';

class BeslenmeprogramiprogramState extends Equatable {
  BeslenmeprogramiprogramState({this.beslenmeprogramiprogramModelObj});

  BeslenmeprogramiprogramModel? beslenmeprogramiprogramModelObj;

  @override
  List<Object?> get props => [
        beslenmeprogramiprogramModelObj,
      ];
  BeslenmeprogramiprogramState copyWith(
      {BeslenmeprogramiprogramModel? beslenmeprogramiprogramModelObj}) {
    return BeslenmeprogramiprogramState(
      beslenmeprogramiprogramModelObj: beslenmeprogramiprogramModelObj ??
          this.beslenmeprogramiprogramModelObj,
    );
  }
}
