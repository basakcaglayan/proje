import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/beslenmeprogramiprogram_screen/models/beslenmeprogramiprogram_model.dart';part 'beslenmeprogramiprogram_event.dart';part 'beslenmeprogramiprogram_state.dart';class BeslenmeprogramiprogramBloc extends Bloc<BeslenmeprogramiprogramEvent, BeslenmeprogramiprogramState> {BeslenmeprogramiprogramBloc(BeslenmeprogramiprogramState initialState) : super(initialState) { on<BeslenmeprogramiprogramInitialEvent>(_onInitialize); }

_onInitialize(BeslenmeprogramiprogramInitialEvent event, Emitter<BeslenmeprogramiprogramState> emit, ) async  {  } 
 }
