// ignore_for_file: must_be_immutable

part of 'beslenmevegan_bloc.dart';

class BeslenmeveganState extends Equatable {
  BeslenmeveganState({this.beslenmeveganModelObj});

  BeslenmeveganModel? beslenmeveganModelObj;

  @override
  List<Object?> get props => [
        beslenmeveganModelObj,
      ];
  BeslenmeveganState copyWith({BeslenmeveganModel? beslenmeveganModelObj}) {
    return BeslenmeveganState(
      beslenmeveganModelObj:
          beslenmeveganModelObj ?? this.beslenmeveganModelObj,
    );
  }
}
