import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/beslenmevegan_screen/models/beslenmevegan_model.dart';part 'beslenmevegan_event.dart';part 'beslenmevegan_state.dart';class BeslenmeveganBloc extends Bloc<BeslenmeveganEvent, BeslenmeveganState> {BeslenmeveganBloc(BeslenmeveganState initialState) : super(initialState) { on<BeslenmeveganInitialEvent>(_onInitialize); }

_onInitialize(BeslenmeveganInitialEvent event, Emitter<BeslenmeveganState> emit, ) async  {  } 
 }
