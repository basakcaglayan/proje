// ignore_for_file: must_be_immutable

part of 'beslenmevegan_bloc.dart';

@immutable
abstract class BeslenmeveganEvent extends Equatable {}

class BeslenmeveganInitialEvent extends BeslenmeveganEvent {
  @override
  List<Object?> get props => [];
}
