import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class BeslenmeveganModel extends Equatable {BeslenmeveganModel copyWith() { return BeslenmeveganModel(
); } 
@override List<Object?> get props => [];
 }
