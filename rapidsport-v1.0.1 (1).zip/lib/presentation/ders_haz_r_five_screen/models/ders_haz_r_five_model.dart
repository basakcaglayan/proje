import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class DersHazRFiveModel extends Equatable {DersHazRFiveModel copyWith() { return DersHazRFiveModel(
); } 
@override List<Object?> get props => [];
 }
