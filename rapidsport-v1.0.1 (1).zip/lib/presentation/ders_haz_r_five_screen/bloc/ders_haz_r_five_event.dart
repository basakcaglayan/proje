// ignore_for_file: must_be_immutable

part of 'ders_haz_r_five_bloc.dart';

@immutable
abstract class DersHazRFiveEvent extends Equatable {}

class DersHazRFiveInitialEvent extends DersHazRFiveEvent {
  @override
  List<Object?> get props => [];
}
