// ignore_for_file: must_be_immutable

part of 'ders_haz_r_five_bloc.dart';

class DersHazRFiveState extends Equatable {
  DersHazRFiveState({this.dersHazRFiveModelObj});

  DersHazRFiveModel? dersHazRFiveModelObj;

  @override
  List<Object?> get props => [
        dersHazRFiveModelObj,
      ];
  DersHazRFiveState copyWith({DersHazRFiveModel? dersHazRFiveModelObj}) {
    return DersHazRFiveState(
      dersHazRFiveModelObj: dersHazRFiveModelObj ?? this.dersHazRFiveModelObj,
    );
  }
}
