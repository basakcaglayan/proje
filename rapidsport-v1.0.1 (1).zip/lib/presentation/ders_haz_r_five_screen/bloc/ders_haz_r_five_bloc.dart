import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/ders_haz_r_five_screen/models/ders_haz_r_five_model.dart';part 'ders_haz_r_five_event.dart';part 'ders_haz_r_five_state.dart';class DersHazRFiveBloc extends Bloc<DersHazRFiveEvent, DersHazRFiveState> {DersHazRFiveBloc(DersHazRFiveState initialState) : super(initialState) { on<DersHazRFiveInitialEvent>(_onInitialize); }

_onInitialize(DersHazRFiveInitialEvent event, Emitter<DersHazRFiveState> emit, ) async  {  } 
 }
