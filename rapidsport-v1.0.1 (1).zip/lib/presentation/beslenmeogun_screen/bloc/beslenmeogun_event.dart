// ignore_for_file: must_be_immutable

part of 'beslenmeogun_bloc.dart';

@immutable
abstract class BeslenmeogunEvent extends Equatable {}

class BeslenmeogunInitialEvent extends BeslenmeogunEvent {
  @override
  List<Object?> get props => [];
}
