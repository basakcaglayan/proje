// ignore_for_file: must_be_immutable

part of 'beslenmeogun_bloc.dart';

class BeslenmeogunState extends Equatable {
  BeslenmeogunState({this.beslenmeogunModelObj});

  BeslenmeogunModel? beslenmeogunModelObj;

  @override
  List<Object?> get props => [
        beslenmeogunModelObj,
      ];
  BeslenmeogunState copyWith({BeslenmeogunModel? beslenmeogunModelObj}) {
    return BeslenmeogunState(
      beslenmeogunModelObj: beslenmeogunModelObj ?? this.beslenmeogunModelObj,
    );
  }
}
