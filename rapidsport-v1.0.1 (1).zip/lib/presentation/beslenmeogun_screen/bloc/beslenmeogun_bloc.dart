import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/beslenmeogun_screen/models/beslenmeogun_model.dart';part 'beslenmeogun_event.dart';part 'beslenmeogun_state.dart';class BeslenmeogunBloc extends Bloc<BeslenmeogunEvent, BeslenmeogunState> {BeslenmeogunBloc(BeslenmeogunState initialState) : super(initialState) { on<BeslenmeogunInitialEvent>(_onInitialize); }

_onInitialize(BeslenmeogunInitialEvent event, Emitter<BeslenmeogunState> emit, ) async  {  } 
 }
