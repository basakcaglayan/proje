import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class BeslenmeogunModel extends Equatable {BeslenmeogunModel copyWith() { return BeslenmeogunModel(
); } 
@override List<Object?> get props => [];
 }
