import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class AntrenmanturModel extends Equatable {AntrenmanturModel copyWith() { return AntrenmanturModel(
); } 
@override List<Object?> get props => [];
 }
