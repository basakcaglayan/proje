import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/antrenmantur_screen/models/antrenmantur_model.dart';part 'antrenmantur_event.dart';part 'antrenmantur_state.dart';class AntrenmanturBloc extends Bloc<AntrenmanturEvent, AntrenmanturState> {AntrenmanturBloc(AntrenmanturState initialState) : super(initialState) { on<AntrenmanturInitialEvent>(_onInitialize); }

_onInitialize(AntrenmanturInitialEvent event, Emitter<AntrenmanturState> emit, ) async  {  } 
 }
