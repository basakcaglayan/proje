// ignore_for_file: must_be_immutable

part of 'antrenmantur_bloc.dart';

class AntrenmanturState extends Equatable {
  AntrenmanturState({this.antrenmanturModelObj});

  AntrenmanturModel? antrenmanturModelObj;

  @override
  List<Object?> get props => [
        antrenmanturModelObj,
      ];
  AntrenmanturState copyWith({AntrenmanturModel? antrenmanturModelObj}) {
    return AntrenmanturState(
      antrenmanturModelObj: antrenmanturModelObj ?? this.antrenmanturModelObj,
    );
  }
}
