// ignore_for_file: must_be_immutable

part of 'antrenmantur_bloc.dart';

@immutable
abstract class AntrenmanturEvent extends Equatable {}

class AntrenmanturInitialEvent extends AntrenmanturEvent {
  @override
  List<Object?> get props => [];
}
