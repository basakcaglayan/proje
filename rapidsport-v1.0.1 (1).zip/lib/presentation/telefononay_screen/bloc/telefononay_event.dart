// ignore_for_file: must_be_immutable

part of 'telefononay_bloc.dart';

@immutable
abstract class TelefononayEvent extends Equatable {}

class TelefononayInitialEvent extends TelefononayEvent {
  @override
  List<Object?> get props => [];
}

///event for OTP auto fill
class ChangeOTPEvent extends TelefononayEvent {
  ChangeOTPEvent({required this.code});

  String code;

  @override
  List<Object?> get props => [
        code,
      ];
}
