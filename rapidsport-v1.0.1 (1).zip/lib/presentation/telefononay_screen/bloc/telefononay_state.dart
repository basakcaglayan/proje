// ignore_for_file: must_be_immutable

part of 'telefononay_bloc.dart';

class TelefononayState extends Equatable {
  TelefononayState({
    this.otpController,
    this.telefononayModelObj,
  });

  TextEditingController? otpController;

  TelefononayModel? telefononayModelObj;

  @override
  List<Object?> get props => [
        otpController,
        telefononayModelObj,
      ];
  TelefononayState copyWith({
    TextEditingController? otpController,
    TelefononayModel? telefononayModelObj,
  }) {
    return TelefononayState(
      otpController: otpController ?? this.otpController,
      telefononayModelObj: telefononayModelObj ?? this.telefononayModelObj,
    );
  }
}
