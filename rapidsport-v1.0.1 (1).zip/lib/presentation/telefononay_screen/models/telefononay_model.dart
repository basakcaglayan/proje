import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class TelefononayModel extends Equatable {TelefononayModel copyWith() { return TelefononayModel(
); } 
@override List<Object?> get props => [];
 }
