import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class DersonayModel extends Equatable {DersonayModel copyWith() { return DersonayModel(
); } 
@override List<Object?> get props => [];
 }
