// ignore_for_file: must_be_immutable

part of 'dersonay_bloc.dart';

@immutable
abstract class DersonayEvent extends Equatable {}

class DersonayInitialEvent extends DersonayEvent {
  @override
  List<Object?> get props => [];
}
