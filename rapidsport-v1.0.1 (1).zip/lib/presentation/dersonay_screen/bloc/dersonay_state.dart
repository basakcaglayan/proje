// ignore_for_file: must_be_immutable

part of 'dersonay_bloc.dart';

class DersonayState extends Equatable {
  DersonayState({
    this.commentController,
    this.dersonayModelObj,
  });

  TextEditingController? commentController;

  DersonayModel? dersonayModelObj;

  @override
  List<Object?> get props => [
        commentController,
        dersonayModelObj,
      ];
  DersonayState copyWith({
    TextEditingController? commentController,
    DersonayModel? dersonayModelObj,
  }) {
    return DersonayState(
      commentController: commentController ?? this.commentController,
      dersonayModelObj: dersonayModelObj ?? this.dersonayModelObj,
    );
  }
}
