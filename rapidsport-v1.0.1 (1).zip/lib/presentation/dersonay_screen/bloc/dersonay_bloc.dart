import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/dersonay_screen/models/dersonay_model.dart';part 'dersonay_event.dart';part 'dersonay_state.dart';class DersonayBloc extends Bloc<DersonayEvent, DersonayState> {DersonayBloc(DersonayState initialState) : super(initialState) { on<DersonayInitialEvent>(_onInitialize); }

_onInitialize(DersonayInitialEvent event, Emitter<DersonayState> emit, ) async  { emit(state.copyWith(commentController: TextEditingController())); } 
 }
