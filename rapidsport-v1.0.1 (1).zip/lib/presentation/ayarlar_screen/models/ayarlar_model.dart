import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class AyarlarModel extends Equatable {AyarlarModel copyWith() { return AyarlarModel(
); } 
@override List<Object?> get props => [];
 }
