// ignore_for_file: must_be_immutable

part of 'ayarlar_bloc.dart';

@immutable
abstract class AyarlarEvent extends Equatable {}

class AyarlarInitialEvent extends AyarlarEvent {
  @override
  List<Object?> get props => [];
}
