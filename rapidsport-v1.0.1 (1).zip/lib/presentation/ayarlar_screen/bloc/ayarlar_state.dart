// ignore_for_file: must_be_immutable

part of 'ayarlar_bloc.dart';

class AyarlarState extends Equatable {
  AyarlarState({
    this.profilesettingsController,
    this.paymentprocesseController,
    this.ayarlarModelObj,
  });

  TextEditingController? profilesettingsController;

  TextEditingController? paymentprocesseController;

  AyarlarModel? ayarlarModelObj;

  @override
  List<Object?> get props => [
        profilesettingsController,
        paymentprocesseController,
        ayarlarModelObj,
      ];
  AyarlarState copyWith({
    TextEditingController? profilesettingsController,
    TextEditingController? paymentprocesseController,
    AyarlarModel? ayarlarModelObj,
  }) {
    return AyarlarState(
      profilesettingsController:
          profilesettingsController ?? this.profilesettingsController,
      paymentprocesseController:
          paymentprocesseController ?? this.paymentprocesseController,
      ayarlarModelObj: ayarlarModelObj ?? this.ayarlarModelObj,
    );
  }
}
