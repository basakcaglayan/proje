import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/ayarlar_screen/models/ayarlar_model.dart';part 'ayarlar_event.dart';part 'ayarlar_state.dart';class AyarlarBloc extends Bloc<AyarlarEvent, AyarlarState> {AyarlarBloc(AyarlarState initialState) : super(initialState) { on<AyarlarInitialEvent>(_onInitialize); }

_onInitialize(AyarlarInitialEvent event, Emitter<AyarlarState> emit, ) async  { emit(state.copyWith(profilesettingsController: TextEditingController(), paymentprocesseController: TextEditingController())); } 
 }
