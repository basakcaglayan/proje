// ignore_for_file: must_be_immutable

part of 'beslenmekalori_bloc.dart';

class BeslenmekaloriState extends Equatable {
  BeslenmekaloriState({this.beslenmekaloriModelObj});

  BeslenmekaloriModel? beslenmekaloriModelObj;

  @override
  List<Object?> get props => [
        beslenmekaloriModelObj,
      ];
  BeslenmekaloriState copyWith({BeslenmekaloriModel? beslenmekaloriModelObj}) {
    return BeslenmekaloriState(
      beslenmekaloriModelObj:
          beslenmekaloriModelObj ?? this.beslenmekaloriModelObj,
    );
  }
}
