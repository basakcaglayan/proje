import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/beslenmekalori_screen/models/beslenmekalori_model.dart';part 'beslenmekalori_event.dart';part 'beslenmekalori_state.dart';class BeslenmekaloriBloc extends Bloc<BeslenmekaloriEvent, BeslenmekaloriState> {BeslenmekaloriBloc(BeslenmekaloriState initialState) : super(initialState) { on<BeslenmekaloriInitialEvent>(_onInitialize); }

_onInitialize(BeslenmekaloriInitialEvent event, Emitter<BeslenmekaloriState> emit, ) async  {  } 
 }
