// ignore_for_file: must_be_immutable

part of 'beslenmekalori_bloc.dart';

@immutable
abstract class BeslenmekaloriEvent extends Equatable {}

class BeslenmekaloriInitialEvent extends BeslenmekaloriEvent {
  @override
  List<Object?> get props => [];
}
