import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class BeslenmekaloriModel extends Equatable {BeslenmekaloriModel copyWith() { return BeslenmekaloriModel(
); } 
@override List<Object?> get props => [];
 }
