import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class RezervasyononayModel extends Equatable {RezervasyononayModel copyWith() { return RezervasyononayModel(
); } 
@override List<Object?> get props => [];
 }
