// ignore_for_file: must_be_immutable

part of 'rezervasyononay_bloc.dart';

class RezervasyononayState extends Equatable {
  RezervasyononayState({this.rezervasyononayModelObj});

  RezervasyononayModel? rezervasyononayModelObj;

  @override
  List<Object?> get props => [
        rezervasyononayModelObj,
      ];
  RezervasyononayState copyWith(
      {RezervasyononayModel? rezervasyononayModelObj}) {
    return RezervasyononayState(
      rezervasyononayModelObj:
          rezervasyononayModelObj ?? this.rezervasyononayModelObj,
    );
  }
}
