// ignore_for_file: must_be_immutable

part of 'rezervasyononay_bloc.dart';

@immutable
abstract class RezervasyononayEvent extends Equatable {}

class RezervasyononayInitialEvent extends RezervasyononayEvent {
  @override
  List<Object?> get props => [];
}
