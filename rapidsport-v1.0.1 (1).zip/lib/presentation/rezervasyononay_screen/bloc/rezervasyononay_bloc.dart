import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/rezervasyononay_screen/models/rezervasyononay_model.dart';part 'rezervasyononay_event.dart';part 'rezervasyononay_state.dart';class RezervasyononayBloc extends Bloc<RezervasyononayEvent, RezervasyononayState> {RezervasyononayBloc(RezervasyononayState initialState) : super(initialState) { on<RezervasyononayInitialEvent>(_onInitialize); }

_onInitialize(RezervasyononayInitialEvent event, Emitter<RezervasyononayState> emit, ) async  {  } 
 }
