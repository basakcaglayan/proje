// ignore_for_file: must_be_immutable

part of 'anasayfa_bloc.dart';

@immutable
abstract class AnasayfaEvent extends Equatable {}

class AnasayfaInitialEvent extends AnasayfaEvent {
  @override
  List<Object?> get props => [];
}
