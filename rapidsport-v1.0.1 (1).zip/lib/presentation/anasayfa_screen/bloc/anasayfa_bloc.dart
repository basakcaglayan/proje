import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/anasayfa_screen/models/anasayfa_model.dart';part 'anasayfa_event.dart';part 'anasayfa_state.dart';class AnasayfaBloc extends Bloc<AnasayfaEvent, AnasayfaState> {AnasayfaBloc(AnasayfaState initialState) : super(initialState) { on<AnasayfaInitialEvent>(_onInitialize); }

_onInitialize(AnasayfaInitialEvent event, Emitter<AnasayfaState> emit, ) async  { Future.delayed(const Duration(milliseconds: 3000), (){
NavigatorService.popAndPushNamed(AppRoutes.yakindakiantrenorlerigorScreen, );}); } 
 }
