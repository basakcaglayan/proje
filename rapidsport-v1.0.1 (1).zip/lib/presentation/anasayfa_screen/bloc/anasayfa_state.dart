// ignore_for_file: must_be_immutable

part of 'anasayfa_bloc.dart';

class AnasayfaState extends Equatable {
  AnasayfaState({this.anasayfaModelObj});

  AnasayfaModel? anasayfaModelObj;

  @override
  List<Object?> get props => [
        anasayfaModelObj,
      ];
  AnasayfaState copyWith({AnasayfaModel? anasayfaModelObj}) {
    return AnasayfaState(
      anasayfaModelObj: anasayfaModelObj ?? this.anasayfaModelObj,
    );
  }
}
