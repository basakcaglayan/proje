import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class AnasayfaModel extends Equatable {AnasayfaModel copyWith() { return AnasayfaModel(
); } 
@override List<Object?> get props => [];
 }
