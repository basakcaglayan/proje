import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:rapidsport/presentation/ders_haz_r_four_screen/models/ders_haz_r_four_model.dart';
part 'ders_haz_r_four_event.dart';
part 'ders_haz_r_four_state.dart';

class DersHazRFourBloc extends Bloc<DersHazRFourEvent, DersHazRFourState> {
  DersHazRFourBloc(DersHazRFourState initialState) : super(initialState) {
    on<DersHazRFourInitialEvent>(_onInitialize);
  }

  _onInitialize(
    DersHazRFourInitialEvent event,
    Emitter<DersHazRFourState> emit,
  ) async {}
}
