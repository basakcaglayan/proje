// ignore_for_file: must_be_immutable

part of 'ders_haz_r_four_bloc.dart';

class DersHazRFourState extends Equatable {
  DersHazRFourState({this.dersHazRFourModelObj});

  DersHazRFourModel? dersHazRFourModelObj;

  @override
  List<Object?> get props => [
        dersHazRFourModelObj,
      ];
  DersHazRFourState copyWith({DersHazRFourModel? dersHazRFourModelObj}) {
    return DersHazRFourState(
      dersHazRFourModelObj: dersHazRFourModelObj ?? this.dersHazRFourModelObj,
    );
  }
}
