import 'bloc/ders_haz_r_four_bloc.dart';
import 'models/ders_haz_r_four_model.dart';
import 'package:flutter/material.dart';
import 'package:rapidsport/core/app_export.dart';

class DersHazRFourScreen extends StatelessWidget {
  static Widget builder(BuildContext context) {
    return BlocProvider<DersHazRFourBloc>(
      create: (context) => DersHazRFourBloc(DersHazRFourState(
        dersHazRFourModelObj: DersHazRFourModel(),
      ))
        ..add(DersHazRFourInitialEvent()),
      child: DersHazRFourScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<DersHazRFourBloc, DersHazRFourState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: Container(
              width: getHorizontalSize(
                375,
              ),
              padding: getPadding(
                left: 13,
                right: 13,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: getHorizontalSize(
                      304,
                    ),
                    margin: getMargin(
                      left: 17,
                      right: 28,
                    ),
                    decoration: AppDecoration.txtOutlineBlack9003f,
                    child: Text(
                      "msg_antrenmaniniz_ba_ladi".tr,
                      maxLines: null,
                      textAlign: TextAlign.center,
                      style: AppStyle.txtInterRegular36,
                    ),
                  ),
                  Spacer(),
                  Container(
                    width: double.maxFinite,
                    child: Container(
                      margin: getMargin(
                        left: 1,
                        bottom: 84,
                      ),
                      padding: getPadding(
                        left: 151,
                        right: 151,
                      ),
                      decoration: AppDecoration.fillTeal700.copyWith(
                        borderRadius: BorderRadiusStyle.roundedBorder20,
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            width: getHorizontalSize(
                              41,
                            ),
                            margin: getMargin(
                              bottom: 8,
                            ),
                            child: Text(
                              "lbl_evet".tr,
                              maxLines: null,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtAksaraBaliGalangRegular18,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
