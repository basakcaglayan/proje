class Listellipse775ItemModel {String nameTxt = "Julie Capozziello";

String distanceTxt = "30 metre uzaklıkta";

String? id = "";

 }
