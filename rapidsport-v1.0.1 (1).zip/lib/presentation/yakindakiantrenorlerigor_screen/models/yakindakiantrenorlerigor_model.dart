import 'package:equatable/equatable.dart';import 'listellipse775_item_model.dart';
// ignore: must_be_immutable
class YakindakiantrenorlerigorModel extends Equatable {YakindakiantrenorlerigorModel({this.listellipse775ItemList = const []});

List<Listellipse775ItemModel> listellipse775ItemList;

YakindakiantrenorlerigorModel copyWith({List<Listellipse775ItemModel>? listellipse775ItemList}) { return YakindakiantrenorlerigorModel(
listellipse775ItemList : listellipse775ItemList ?? this.listellipse775ItemList,
); } 
@override List<Object?> get props => [listellipse775ItemList];
 }
