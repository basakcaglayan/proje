// ignore_for_file: must_be_immutable

part of 'yakindakiantrenorlerigor_bloc.dart';

@immutable
abstract class YakindakiantrenorlerigorEvent extends Equatable {}

class YakindakiantrenorlerigorInitialEvent
    extends YakindakiantrenorlerigorEvent {
  @override
  List<Object?> get props => [];
}
