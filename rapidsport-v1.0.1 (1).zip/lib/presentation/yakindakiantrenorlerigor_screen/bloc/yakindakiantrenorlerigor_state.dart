// ignore_for_file: must_be_immutable

part of 'yakindakiantrenorlerigor_bloc.dart';

class YakindakiantrenorlerigorState extends Equatable {
  YakindakiantrenorlerigorState({this.yakindakiantrenorlerigorModelObj});

  YakindakiantrenorlerigorModel? yakindakiantrenorlerigorModelObj;

  @override
  List<Object?> get props => [
        yakindakiantrenorlerigorModelObj,
      ];
  YakindakiantrenorlerigorState copyWith(
      {YakindakiantrenorlerigorModel? yakindakiantrenorlerigorModelObj}) {
    return YakindakiantrenorlerigorState(
      yakindakiantrenorlerigorModelObj: yakindakiantrenorlerigorModelObj ??
          this.yakindakiantrenorlerigorModelObj,
    );
  }
}
