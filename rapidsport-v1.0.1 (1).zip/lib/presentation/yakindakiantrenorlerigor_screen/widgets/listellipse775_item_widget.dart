import '../models/listellipse775_item_model.dart';
import 'package:flutter/material.dart';
import 'package:rapidsport/core/app_export.dart';

// ignore: must_be_immutable
class Listellipse775ItemWidget extends StatelessWidget {
  Listellipse775ItemWidget(this.listellipse775ItemModelObj);

  Listellipse775ItemModel listellipse775ItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Container(
        padding: getPadding(
          left: 8,
          top: 4,
          right: 8,
          bottom: 4,
        ),
        decoration: AppDecoration.outlineBlack900143.copyWith(
          borderRadius: BorderRadiusStyle.roundedBorder5,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              margin: getMargin(
                top: 3,
                bottom: 4,
              ),
              decoration: AppDecoration.outlineBlack9003f,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(
                    height: getVerticalSize(
                      18,
                    ),
                    width: getHorizontalSize(
                      20,
                    ),
                    margin: getMargin(
                      top: 9,
                    ),
                    decoration: BoxDecoration(
                      color: ColorConstant.whiteA700,
                      borderRadius: BorderRadius.circular(
                        getHorizontalSize(
                          10,
                        ),
                      ),
                    ),
                  ),
                  CustomImageView(
                    svgPath: ImageConstant.imgSave,
                    height: getVerticalSize(
                      18,
                    ),
                    width: getHorizontalSize(
                      40,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Padding(
                padding: getPadding(
                  left: 11,
                  top: 12,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text(
                      listellipse775ItemModelObj.nameTxt,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtInterRegular14,
                    ),
                    Padding(
                      padding: getPadding(
                        top: 1,
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CustomImageView(
                            imagePath: ImageConstant.imgImage17,
                            height: getVerticalSize(
                              15,
                            ),
                            width: getHorizontalSize(
                              77,
                            ),
                            margin: getMargin(
                              bottom: 7,
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              left: 80,
                              top: 9,
                            ),
                            child: Text(
                              listellipse775ItemModelObj.distanceTxt,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterRegular10,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
