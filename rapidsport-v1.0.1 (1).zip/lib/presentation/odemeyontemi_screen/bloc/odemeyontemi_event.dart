// ignore_for_file: must_be_immutable

part of 'odemeyontemi_bloc.dart';

@immutable
abstract class OdemeyontemiEvent extends Equatable {}

class OdemeyontemiInitialEvent extends OdemeyontemiEvent {
  @override
  List<Object?> get props => [];
}
