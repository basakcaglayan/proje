// ignore_for_file: must_be_immutable

part of 'odemeyontemi_bloc.dart';

class OdemeyontemiState extends Equatable {
  OdemeyontemiState({
    this.cvvController,
    this.cvvoneController,
    this.odemeyontemiModelObj,
  });

  TextEditingController? cvvController;

  TextEditingController? cvvoneController;

  OdemeyontemiModel? odemeyontemiModelObj;

  @override
  List<Object?> get props => [
        cvvController,
        cvvoneController,
        odemeyontemiModelObj,
      ];
  OdemeyontemiState copyWith({
    TextEditingController? cvvController,
    TextEditingController? cvvoneController,
    OdemeyontemiModel? odemeyontemiModelObj,
  }) {
    return OdemeyontemiState(
      cvvController: cvvController ?? this.cvvController,
      cvvoneController: cvvoneController ?? this.cvvoneController,
      odemeyontemiModelObj: odemeyontemiModelObj ?? this.odemeyontemiModelObj,
    );
  }
}
