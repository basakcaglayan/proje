import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/odemeyontemi_screen/models/odemeyontemi_model.dart';part 'odemeyontemi_event.dart';part 'odemeyontemi_state.dart';class OdemeyontemiBloc extends Bloc<OdemeyontemiEvent, OdemeyontemiState> {OdemeyontemiBloc(OdemeyontemiState initialState) : super(initialState) { on<OdemeyontemiInitialEvent>(_onInitialize); }

_onInitialize(OdemeyontemiInitialEvent event, Emitter<OdemeyontemiState> emit, ) async  { emit(state.copyWith(cvvController: TextEditingController(), cvvoneController: TextEditingController())); } 
 }
