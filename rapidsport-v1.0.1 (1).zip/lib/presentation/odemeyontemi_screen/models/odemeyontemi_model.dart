import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class OdemeyontemiModel extends Equatable {OdemeyontemiModel copyWith() { return OdemeyontemiModel(
); } 
@override List<Object?> get props => [];
 }
