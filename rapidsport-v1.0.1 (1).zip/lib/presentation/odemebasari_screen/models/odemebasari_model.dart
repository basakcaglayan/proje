import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class OdemebasariModel extends Equatable {OdemebasariModel copyWith() { return OdemebasariModel(
); } 
@override List<Object?> get props => [];
 }
