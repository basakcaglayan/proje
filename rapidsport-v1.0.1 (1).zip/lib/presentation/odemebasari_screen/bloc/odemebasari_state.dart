// ignore_for_file: must_be_immutable

part of 'odemebasari_bloc.dart';

class OdemebasariState extends Equatable {
  OdemebasariState({this.odemebasariModelObj});

  OdemebasariModel? odemebasariModelObj;

  @override
  List<Object?> get props => [
        odemebasariModelObj,
      ];
  OdemebasariState copyWith({OdemebasariModel? odemebasariModelObj}) {
    return OdemebasariState(
      odemebasariModelObj: odemebasariModelObj ?? this.odemebasariModelObj,
    );
  }
}
