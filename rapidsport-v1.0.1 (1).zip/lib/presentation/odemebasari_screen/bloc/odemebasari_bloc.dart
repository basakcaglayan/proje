import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/odemebasari_screen/models/odemebasari_model.dart';part 'odemebasari_event.dart';part 'odemebasari_state.dart';class OdemebasariBloc extends Bloc<OdemebasariEvent, OdemebasariState> {OdemebasariBloc(OdemebasariState initialState) : super(initialState) { on<OdemebasariInitialEvent>(_onInitialize); }

_onInitialize(OdemebasariInitialEvent event, Emitter<OdemebasariState> emit, ) async  {  } 
 }
