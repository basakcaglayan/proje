// ignore_for_file: must_be_immutable

part of 'odemebasari_bloc.dart';

@immutable
abstract class OdemebasariEvent extends Equatable {}

class OdemebasariInitialEvent extends OdemebasariEvent {
  @override
  List<Object?> get props => [];
}
