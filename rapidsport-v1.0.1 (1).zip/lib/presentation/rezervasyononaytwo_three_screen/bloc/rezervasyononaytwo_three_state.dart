// ignore_for_file: must_be_immutable

part of 'rezervasyononaytwo_three_bloc.dart';

class RezervasyononaytwoThreeState extends Equatable {
  RezervasyononaytwoThreeState({this.rezervasyononaytwoThreeModelObj});

  RezervasyononaytwoThreeModel? rezervasyononaytwoThreeModelObj;

  @override
  List<Object?> get props => [
        rezervasyononaytwoThreeModelObj,
      ];
  RezervasyononaytwoThreeState copyWith(
      {RezervasyononaytwoThreeModel? rezervasyononaytwoThreeModelObj}) {
    return RezervasyononaytwoThreeState(
      rezervasyononaytwoThreeModelObj: rezervasyononaytwoThreeModelObj ??
          this.rezervasyononaytwoThreeModelObj,
    );
  }
}
