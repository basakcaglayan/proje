import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import '../models/listdate_item_model.dart';import 'package:rapidsport/presentation/rezervasyononaytwo_three_screen/models/rezervasyononaytwo_three_model.dart';part 'rezervasyononaytwo_three_event.dart';part 'rezervasyononaytwo_three_state.dart';class RezervasyononaytwoThreeBloc extends Bloc<RezervasyononaytwoThreeEvent, RezervasyononaytwoThreeState> {RezervasyononaytwoThreeBloc(RezervasyononaytwoThreeState initialState) : super(initialState) { on<RezervasyononaytwoThreeInitialEvent>(_onInitialize); }

_onInitialize(RezervasyononaytwoThreeInitialEvent event, Emitter<RezervasyononaytwoThreeState> emit, ) async  { emit(state.copyWith(rezervasyononaytwoThreeModelObj: state.rezervasyononaytwoThreeModelObj?.copyWith(listdateItemList: fillListdateItemList()))); } 
List<ListdateItemModel> fillListdateItemList() { return List.generate(5, (index) => ListdateItemModel()); } 
 }
