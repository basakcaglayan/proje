// ignore_for_file: must_be_immutable

part of 'rezervasyononaytwo_three_bloc.dart';

@immutable
abstract class RezervasyononaytwoThreeEvent extends Equatable {}

class RezervasyononaytwoThreeInitialEvent extends RezervasyononaytwoThreeEvent {
  @override
  List<Object?> get props => [];
}
