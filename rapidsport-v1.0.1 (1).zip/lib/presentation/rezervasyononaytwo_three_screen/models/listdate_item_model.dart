class ListdateItemModel {String dateTxt = "13.05.2023";

String timeTxt = "20.00-21.00";

String? id = "";

 }
