import 'package:equatable/equatable.dart';import 'listdate_item_model.dart';
// ignore: must_be_immutable
class RezervasyononaytwoThreeModel extends Equatable {RezervasyononaytwoThreeModel({this.listdateItemList = const []});

List<ListdateItemModel> listdateItemList;

RezervasyononaytwoThreeModel copyWith({List<ListdateItemModel>? listdateItemList}) { return RezervasyononaytwoThreeModel(
listdateItemList : listdateItemList ?? this.listdateItemList,
); } 
@override List<Object?> get props => [listdateItemList];
 }
