import '../models/listdate_item_model.dart';
import 'package:flutter/material.dart';
import 'package:rapidsport/core/app_export.dart';

// ignore: must_be_immutable
class ListdateItemWidget extends StatelessWidget {
  ListdateItemWidget(this.listdateItemModelObj);

  ListdateItemModel listdateItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: getPadding(
        left: 23,
        top: 15,
        right: 23,
        bottom: 15,
      ),
      decoration: AppDecoration.fillTeal70066.copyWith(
        borderRadius: BorderRadiusStyle.circleBorder28,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: getPadding(
              top: 1,
              bottom: 3,
            ),
            child: Text(
              listdateItemModelObj.dateTxt,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.left,
              style: AppStyle.txtInterBold16,
            ),
          ),
          Padding(
            padding: getPadding(
              left: 25,
              top: 1,
              bottom: 3,
            ),
            child: Text(
              listdateItemModelObj.timeTxt,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.left,
              style: AppStyle.txtInterBold16,
            ),
          ),
          Padding(
            padding: getPadding(
              left: 33,
              bottom: 5,
            ),
            child: Text(
              "lbl_ten_s".tr,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.left,
              style: AppStyle.txtInterBold16,
            ),
          ),
        ],
      ),
    );
  }
}
