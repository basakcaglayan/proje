// ignore_for_file: must_be_immutable

part of 'ders_haz_r_two_bloc.dart';

class DersHazRTwoState extends Equatable {
  DersHazRTwoState({this.dersHazRTwoModelObj});

  DersHazRTwoModel? dersHazRTwoModelObj;

  @override
  List<Object?> get props => [
        dersHazRTwoModelObj,
      ];
  DersHazRTwoState copyWith({DersHazRTwoModel? dersHazRTwoModelObj}) {
    return DersHazRTwoState(
      dersHazRTwoModelObj: dersHazRTwoModelObj ?? this.dersHazRTwoModelObj,
    );
  }
}
