import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/ders_haz_r_two_screen/models/ders_haz_r_two_model.dart';part 'ders_haz_r_two_event.dart';part 'ders_haz_r_two_state.dart';class DersHazRTwoBloc extends Bloc<DersHazRTwoEvent, DersHazRTwoState> {DersHazRTwoBloc(DersHazRTwoState initialState) : super(initialState) { on<DersHazRTwoInitialEvent>(_onInitialize); }

_onInitialize(DersHazRTwoInitialEvent event, Emitter<DersHazRTwoState> emit, ) async  {  } 
 }
