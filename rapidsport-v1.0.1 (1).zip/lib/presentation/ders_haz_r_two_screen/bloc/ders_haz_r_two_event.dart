// ignore_for_file: must_be_immutable

part of 'ders_haz_r_two_bloc.dart';

@immutable
abstract class DersHazRTwoEvent extends Equatable {}

class DersHazRTwoInitialEvent extends DersHazRTwoEvent {
  @override
  List<Object?> get props => [];
}
