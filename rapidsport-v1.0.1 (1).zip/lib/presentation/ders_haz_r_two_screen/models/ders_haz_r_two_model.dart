import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class DersHazRTwoModel extends Equatable {DersHazRTwoModel copyWith() { return DersHazRTwoModel(
); } 
@override List<Object?> get props => [];
 }
