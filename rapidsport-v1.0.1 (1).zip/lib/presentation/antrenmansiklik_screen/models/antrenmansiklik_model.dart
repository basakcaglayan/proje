import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class AntrenmansiklikModel extends Equatable {AntrenmansiklikModel copyWith() { return AntrenmansiklikModel(
); } 
@override List<Object?> get props => [];
 }
