// ignore_for_file: must_be_immutable

part of 'antrenmansiklik_bloc.dart';

@immutable
abstract class AntrenmansiklikEvent extends Equatable {}

class AntrenmansiklikInitialEvent extends AntrenmansiklikEvent {
  @override
  List<Object?> get props => [];
}
