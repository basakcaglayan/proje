// ignore_for_file: must_be_immutable

part of 'antrenmansiklik_bloc.dart';

class AntrenmansiklikState extends Equatable {
  AntrenmansiklikState({this.antrenmansiklikModelObj});

  AntrenmansiklikModel? antrenmansiklikModelObj;

  @override
  List<Object?> get props => [
        antrenmansiklikModelObj,
      ];
  AntrenmansiklikState copyWith(
      {AntrenmansiklikModel? antrenmansiklikModelObj}) {
    return AntrenmansiklikState(
      antrenmansiklikModelObj:
          antrenmansiklikModelObj ?? this.antrenmansiklikModelObj,
    );
  }
}
