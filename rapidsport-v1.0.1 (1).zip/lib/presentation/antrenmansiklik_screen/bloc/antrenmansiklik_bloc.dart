import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/antrenmansiklik_screen/models/antrenmansiklik_model.dart';part 'antrenmansiklik_event.dart';part 'antrenmansiklik_state.dart';class AntrenmansiklikBloc extends Bloc<AntrenmansiklikEvent, AntrenmansiklikState> {AntrenmansiklikBloc(AntrenmansiklikState initialState) : super(initialState) { on<AntrenmansiklikInitialEvent>(_onInitialize); }

_onInitialize(AntrenmansiklikInitialEvent event, Emitter<AntrenmansiklikState> emit, ) async  {  } 
 }
