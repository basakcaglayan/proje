import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class AyarlarTwoModel extends Equatable {AyarlarTwoModel copyWith() { return AyarlarTwoModel(
); } 
@override List<Object?> get props => [];
 }
