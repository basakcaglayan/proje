// ignore_for_file: must_be_immutable

part of 'ayarlar_two_bloc.dart';

class AyarlarTwoState extends Equatable {
  AyarlarTwoState({
    this.packagesController,
    this.paymentmethodController,
    this.ayarlarTwoModelObj,
  });

  TextEditingController? packagesController;

  TextEditingController? paymentmethodController;

  AyarlarTwoModel? ayarlarTwoModelObj;

  @override
  List<Object?> get props => [
        packagesController,
        paymentmethodController,
        ayarlarTwoModelObj,
      ];
  AyarlarTwoState copyWith({
    TextEditingController? packagesController,
    TextEditingController? paymentmethodController,
    AyarlarTwoModel? ayarlarTwoModelObj,
  }) {
    return AyarlarTwoState(
      packagesController: packagesController ?? this.packagesController,
      paymentmethodController:
          paymentmethodController ?? this.paymentmethodController,
      ayarlarTwoModelObj: ayarlarTwoModelObj ?? this.ayarlarTwoModelObj,
    );
  }
}
