import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/ayarlar_two_screen/models/ayarlar_two_model.dart';part 'ayarlar_two_event.dart';part 'ayarlar_two_state.dart';class AyarlarTwoBloc extends Bloc<AyarlarTwoEvent, AyarlarTwoState> {AyarlarTwoBloc(AyarlarTwoState initialState) : super(initialState) { on<AyarlarTwoInitialEvent>(_onInitialize); }

_onInitialize(AyarlarTwoInitialEvent event, Emitter<AyarlarTwoState> emit, ) async  { emit(state.copyWith(packagesController: TextEditingController(), paymentmethodController: TextEditingController())); } 
 }
