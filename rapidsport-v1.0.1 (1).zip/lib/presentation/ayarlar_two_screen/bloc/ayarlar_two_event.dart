// ignore_for_file: must_be_immutable

part of 'ayarlar_two_bloc.dart';

@immutable
abstract class AyarlarTwoEvent extends Equatable {}

class AyarlarTwoInitialEvent extends AyarlarTwoEvent {
  @override
  List<Object?> get props => [];
}
