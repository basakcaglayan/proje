import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class BeslenmefizikselModel extends Equatable {BeslenmefizikselModel copyWith() { return BeslenmefizikselModel(
); } 
@override List<Object?> get props => [];
 }
