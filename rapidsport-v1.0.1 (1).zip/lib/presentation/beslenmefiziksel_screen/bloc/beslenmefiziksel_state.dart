// ignore_for_file: must_be_immutable

part of 'beslenmefiziksel_bloc.dart';

class BeslenmefizikselState extends Equatable {
  BeslenmefizikselState({this.beslenmefizikselModelObj});

  BeslenmefizikselModel? beslenmefizikselModelObj;

  @override
  List<Object?> get props => [
        beslenmefizikselModelObj,
      ];
  BeslenmefizikselState copyWith(
      {BeslenmefizikselModel? beslenmefizikselModelObj}) {
    return BeslenmefizikselState(
      beslenmefizikselModelObj:
          beslenmefizikselModelObj ?? this.beslenmefizikselModelObj,
    );
  }
}
