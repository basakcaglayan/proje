// ignore_for_file: must_be_immutable

part of 'beslenmefiziksel_bloc.dart';

@immutable
abstract class BeslenmefizikselEvent extends Equatable {}

class BeslenmefizikselInitialEvent extends BeslenmefizikselEvent {
  @override
  List<Object?> get props => [];
}
