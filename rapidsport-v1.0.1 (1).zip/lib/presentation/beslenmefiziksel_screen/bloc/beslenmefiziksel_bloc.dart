import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/beslenmefiziksel_screen/models/beslenmefiziksel_model.dart';part 'beslenmefiziksel_event.dart';part 'beslenmefiziksel_state.dart';class BeslenmefizikselBloc extends Bloc<BeslenmefizikselEvent, BeslenmefizikselState> {BeslenmefizikselBloc(BeslenmefizikselState initialState) : super(initialState) { on<BeslenmefizikselInitialEvent>(_onInitialize); }

_onInitialize(BeslenmefizikselInitialEvent event, Emitter<BeslenmefizikselState> emit, ) async  {  } 
 }
