// ignore_for_file: must_be_immutable

part of 'antrenmanoneri_bloc.dart';

@immutable
abstract class AntrenmanoneriEvent extends Equatable {}

class AntrenmanoneriInitialEvent extends AntrenmanoneriEvent {
  @override
  List<Object?> get props => [];
}
