// ignore_for_file: must_be_immutable

part of 'antrenmanoneri_bloc.dart';

class AntrenmanoneriState extends Equatable {
  AntrenmanoneriState({this.antrenmanoneriModelObj});

  AntrenmanoneriModel? antrenmanoneriModelObj;

  @override
  List<Object?> get props => [
        antrenmanoneriModelObj,
      ];
  AntrenmanoneriState copyWith({AntrenmanoneriModel? antrenmanoneriModelObj}) {
    return AntrenmanoneriState(
      antrenmanoneriModelObj:
          antrenmanoneriModelObj ?? this.antrenmanoneriModelObj,
    );
  }
}
