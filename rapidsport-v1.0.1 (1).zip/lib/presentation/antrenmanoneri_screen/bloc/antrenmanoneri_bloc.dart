import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/antrenmanoneri_screen/models/antrenmanoneri_model.dart';part 'antrenmanoneri_event.dart';part 'antrenmanoneri_state.dart';class AntrenmanoneriBloc extends Bloc<AntrenmanoneriEvent, AntrenmanoneriState> {AntrenmanoneriBloc(AntrenmanoneriState initialState) : super(initialState) { on<AntrenmanoneriInitialEvent>(_onInitialize); }

_onInitialize(AntrenmanoneriInitialEvent event, Emitter<AntrenmanoneriState> emit, ) async  {  } 
 }
