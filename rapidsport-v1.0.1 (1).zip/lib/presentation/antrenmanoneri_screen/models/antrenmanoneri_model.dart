import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class AntrenmanoneriModel extends Equatable {AntrenmanoneriModel copyWith() { return AntrenmanoneriModel(
); } 
@override List<Object?> get props => [];
 }
