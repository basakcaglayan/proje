import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class AntrenmanprogramsizModel extends Equatable {AntrenmanprogramsizModel copyWith() { return AntrenmanprogramsizModel(
); } 
@override List<Object?> get props => [];
 }
