// ignore_for_file: must_be_immutable

part of 'antrenmanprogramsiz_bloc.dart';

@immutable
abstract class AntrenmanprogramsizEvent extends Equatable {}

class AntrenmanprogramsizInitialEvent extends AntrenmanprogramsizEvent {
  @override
  List<Object?> get props => [];
}
