import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/antrenmanprogramsiz_screen/models/antrenmanprogramsiz_model.dart';part 'antrenmanprogramsiz_event.dart';part 'antrenmanprogramsiz_state.dart';class AntrenmanprogramsizBloc extends Bloc<AntrenmanprogramsizEvent, AntrenmanprogramsizState> {AntrenmanprogramsizBloc(AntrenmanprogramsizState initialState) : super(initialState) { on<AntrenmanprogramsizInitialEvent>(_onInitialize); }

_onInitialize(AntrenmanprogramsizInitialEvent event, Emitter<AntrenmanprogramsizState> emit, ) async  {  } 
 }
