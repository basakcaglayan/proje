// ignore_for_file: must_be_immutable

part of 'antrenmanprogramsiz_bloc.dart';

class AntrenmanprogramsizState extends Equatable {
  AntrenmanprogramsizState({this.antrenmanprogramsizModelObj});

  AntrenmanprogramsizModel? antrenmanprogramsizModelObj;

  @override
  List<Object?> get props => [
        antrenmanprogramsizModelObj,
      ];
  AntrenmanprogramsizState copyWith(
      {AntrenmanprogramsizModel? antrenmanprogramsizModelObj}) {
    return AntrenmanprogramsizState(
      antrenmanprogramsizModelObj:
          antrenmanprogramsizModelObj ?? this.antrenmanprogramsizModelObj,
    );
  }
}
