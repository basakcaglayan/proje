import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/antrenmanprogrami_screen/models/antrenmanprogrami_model.dart';part 'antrenmanprogrami_event.dart';part 'antrenmanprogrami_state.dart';class AntrenmanprogramiBloc extends Bloc<AntrenmanprogramiEvent, AntrenmanprogramiState> {AntrenmanprogramiBloc(AntrenmanprogramiState initialState) : super(initialState) { on<AntrenmanprogramiInitialEvent>(_onInitialize); }

_onInitialize(AntrenmanprogramiInitialEvent event, Emitter<AntrenmanprogramiState> emit, ) async  {  } 
 }
