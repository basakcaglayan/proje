// ignore_for_file: must_be_immutable

part of 'antrenmanprogrami_bloc.dart';

class AntrenmanprogramiState extends Equatable {
  AntrenmanprogramiState({this.antrenmanprogramiModelObj});

  AntrenmanprogramiModel? antrenmanprogramiModelObj;

  @override
  List<Object?> get props => [
        antrenmanprogramiModelObj,
      ];
  AntrenmanprogramiState copyWith(
      {AntrenmanprogramiModel? antrenmanprogramiModelObj}) {
    return AntrenmanprogramiState(
      antrenmanprogramiModelObj:
          antrenmanprogramiModelObj ?? this.antrenmanprogramiModelObj,
    );
  }
}
