// ignore_for_file: must_be_immutable

part of 'antrenmanprogrami_bloc.dart';

@immutable
abstract class AntrenmanprogramiEvent extends Equatable {}

class AntrenmanprogramiInitialEvent extends AntrenmanprogramiEvent {
  @override
  List<Object?> get props => [];
}
