import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class AntrenmanprogramiModel extends Equatable {AntrenmanprogramiModel copyWith() { return AntrenmanprogramiModel(
); } 
@override List<Object?> get props => [];
 }
