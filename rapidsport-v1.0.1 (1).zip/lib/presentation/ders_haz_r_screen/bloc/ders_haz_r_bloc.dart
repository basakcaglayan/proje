import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/ders_haz_r_screen/models/ders_haz_r_model.dart';part 'ders_haz_r_event.dart';part 'ders_haz_r_state.dart';class DersHazRBloc extends Bloc<DersHazREvent, DersHazRState> {DersHazRBloc(DersHazRState initialState) : super(initialState) { on<DersHazRInitialEvent>(_onInitialize); }

_onInitialize(DersHazRInitialEvent event, Emitter<DersHazRState> emit, ) async  { emit(state.copyWith(groupseventeenController: TextEditingController(), groupthirtysixController: TextEditingController(), groupthirtyseveController: TextEditingController())); } 
 }
