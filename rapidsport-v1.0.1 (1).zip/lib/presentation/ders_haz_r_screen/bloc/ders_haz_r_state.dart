// ignore_for_file: must_be_immutable

part of 'ders_haz_r_bloc.dart';

class DersHazRState extends Equatable {
  DersHazRState({
    this.groupseventeenController,
    this.groupthirtysixController,
    this.groupthirtyseveController,
    this.dersHazRModelObj,
  });

  TextEditingController? groupseventeenController;

  TextEditingController? groupthirtysixController;

  TextEditingController? groupthirtyseveController;

  DersHazRModel? dersHazRModelObj;

  @override
  List<Object?> get props => [
        groupseventeenController,
        groupthirtysixController,
        groupthirtyseveController,
        dersHazRModelObj,
      ];
  DersHazRState copyWith({
    TextEditingController? groupseventeenController,
    TextEditingController? groupthirtysixController,
    TextEditingController? groupthirtyseveController,
    DersHazRModel? dersHazRModelObj,
  }) {
    return DersHazRState(
      groupseventeenController:
          groupseventeenController ?? this.groupseventeenController,
      groupthirtysixController:
          groupthirtysixController ?? this.groupthirtysixController,
      groupthirtyseveController:
          groupthirtyseveController ?? this.groupthirtyseveController,
      dersHazRModelObj: dersHazRModelObj ?? this.dersHazRModelObj,
    );
  }
}
