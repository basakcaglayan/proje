import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class DersHazRModel extends Equatable {DersHazRModel copyWith() { return DersHazRModel(
); } 
@override List<Object?> get props => [];
 }
