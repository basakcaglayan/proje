import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/paketsecimonaylama_screen/models/paketsecimonaylama_model.dart';part 'paketsecimonaylama_event.dart';part 'paketsecimonaylama_state.dart';class PaketsecimonaylamaBloc extends Bloc<PaketsecimonaylamaEvent, PaketsecimonaylamaState> {PaketsecimonaylamaBloc(PaketsecimonaylamaState initialState) : super(initialState) { on<PaketsecimonaylamaInitialEvent>(_onInitialize); }

_onInitialize(PaketsecimonaylamaInitialEvent event, Emitter<PaketsecimonaylamaState> emit, ) async  {  } 
 }
