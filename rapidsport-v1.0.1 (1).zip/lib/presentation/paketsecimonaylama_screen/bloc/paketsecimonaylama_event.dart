// ignore_for_file: must_be_immutable

part of 'paketsecimonaylama_bloc.dart';

@immutable
abstract class PaketsecimonaylamaEvent extends Equatable {}

class PaketsecimonaylamaInitialEvent extends PaketsecimonaylamaEvent {
  @override
  List<Object?> get props => [];
}
