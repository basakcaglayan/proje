// ignore_for_file: must_be_immutable

part of 'paketsecimonaylama_bloc.dart';

class PaketsecimonaylamaState extends Equatable {
  PaketsecimonaylamaState({this.paketsecimonaylamaModelObj});

  PaketsecimonaylamaModel? paketsecimonaylamaModelObj;

  @override
  List<Object?> get props => [
        paketsecimonaylamaModelObj,
      ];
  PaketsecimonaylamaState copyWith(
      {PaketsecimonaylamaModel? paketsecimonaylamaModelObj}) {
    return PaketsecimonaylamaState(
      paketsecimonaylamaModelObj:
          paketsecimonaylamaModelObj ?? this.paketsecimonaylamaModelObj,
    );
  }
}
