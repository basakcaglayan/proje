import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class PaketsecimonaylamaModel extends Equatable {PaketsecimonaylamaModel copyWith() { return PaketsecimonaylamaModel(
); } 
@override List<Object?> get props => [];
 }
