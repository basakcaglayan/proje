import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/rezervasyononaytwo_one_screen/models/rezervasyononaytwo_one_model.dart';part 'rezervasyononaytwo_one_event.dart';part 'rezervasyononaytwo_one_state.dart';class RezervasyononaytwoOneBloc extends Bloc<RezervasyononaytwoOneEvent, RezervasyononaytwoOneState> {RezervasyononaytwoOneBloc(RezervasyononaytwoOneState initialState) : super(initialState) { on<RezervasyononaytwoOneInitialEvent>(_onInitialize); }

_onInitialize(RezervasyononaytwoOneInitialEvent event, Emitter<RezervasyononaytwoOneState> emit, ) async  {  } 
 }
