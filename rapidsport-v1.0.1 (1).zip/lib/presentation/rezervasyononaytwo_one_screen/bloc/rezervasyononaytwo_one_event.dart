// ignore_for_file: must_be_immutable

part of 'rezervasyononaytwo_one_bloc.dart';

@immutable
abstract class RezervasyononaytwoOneEvent extends Equatable {}

class RezervasyononaytwoOneInitialEvent extends RezervasyononaytwoOneEvent {
  @override
  List<Object?> get props => [];
}
