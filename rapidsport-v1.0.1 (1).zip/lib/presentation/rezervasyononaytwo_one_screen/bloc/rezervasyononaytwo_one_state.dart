// ignore_for_file: must_be_immutable

part of 'rezervasyononaytwo_one_bloc.dart';

class RezervasyononaytwoOneState extends Equatable {
  RezervasyononaytwoOneState({this.rezervasyononaytwoOneModelObj});

  RezervasyononaytwoOneModel? rezervasyononaytwoOneModelObj;

  @override
  List<Object?> get props => [
        rezervasyononaytwoOneModelObj,
      ];
  RezervasyononaytwoOneState copyWith(
      {RezervasyononaytwoOneModel? rezervasyononaytwoOneModelObj}) {
    return RezervasyononaytwoOneState(
      rezervasyononaytwoOneModelObj:
          rezervasyononaytwoOneModelObj ?? this.rezervasyononaytwoOneModelObj,
    );
  }
}
