import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class RezervasyononaytwoOneModel extends Equatable {RezervasyononaytwoOneModel copyWith() { return RezervasyononaytwoOneModel(
); } 
@override List<Object?> get props => [];
 }
