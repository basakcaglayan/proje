import 'package:equatable/equatable.dart';
// ignore: must_be_immutable
class BeslenmeboykiloModel extends Equatable {BeslenmeboykiloModel copyWith() { return BeslenmeboykiloModel(
); } 
@override List<Object?> get props => [];
 }
