import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:rapidsport/presentation/beslenmeboykilo_screen/models/beslenmeboykilo_model.dart';part 'beslenmeboykilo_event.dart';part 'beslenmeboykilo_state.dart';class BeslenmeboykiloBloc extends Bloc<BeslenmeboykiloEvent, BeslenmeboykiloState> {BeslenmeboykiloBloc(BeslenmeboykiloState initialState) : super(initialState) { on<BeslenmeboykiloInitialEvent>(_onInitialize); }

_onInitialize(BeslenmeboykiloInitialEvent event, Emitter<BeslenmeboykiloState> emit, ) async  { emit(state.copyWith(inputweightController: TextEditingController(), inputheightController: TextEditingController())); } 
 }
