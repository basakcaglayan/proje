// ignore_for_file: must_be_immutable

part of 'beslenmeboykilo_bloc.dart';

@immutable
abstract class BeslenmeboykiloEvent extends Equatable {}

class BeslenmeboykiloInitialEvent extends BeslenmeboykiloEvent {
  @override
  List<Object?> get props => [];
}
