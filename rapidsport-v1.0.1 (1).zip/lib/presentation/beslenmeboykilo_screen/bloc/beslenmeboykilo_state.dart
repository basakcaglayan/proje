// ignore_for_file: must_be_immutable

part of 'beslenmeboykilo_bloc.dart';

class BeslenmeboykiloState extends Equatable {
  BeslenmeboykiloState({
    this.inputweightController,
    this.inputheightController,
    this.beslenmeboykiloModelObj,
  });

  TextEditingController? inputweightController;

  TextEditingController? inputheightController;

  BeslenmeboykiloModel? beslenmeboykiloModelObj;

  @override
  List<Object?> get props => [
        inputweightController,
        inputheightController,
        beslenmeboykiloModelObj,
      ];
  BeslenmeboykiloState copyWith({
    TextEditingController? inputweightController,
    TextEditingController? inputheightController,
    BeslenmeboykiloModel? beslenmeboykiloModelObj,
  }) {
    return BeslenmeboykiloState(
      inputweightController:
          inputweightController ?? this.inputweightController,
      inputheightController:
          inputheightController ?? this.inputheightController,
      beslenmeboykiloModelObj:
          beslenmeboykiloModelObj ?? this.beslenmeboykiloModelObj,
    );
  }
}
