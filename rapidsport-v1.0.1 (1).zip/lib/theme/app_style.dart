import 'package:flutter/material.dart';
import 'package:rapidsport/core/app_export.dart';

class AppStyle {
  static TextStyle txtDMSansBold14Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'DM Sans',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtABeeZeeItalic14 = TextStyle(
    color: ColorConstant.blueGray900,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'ABeeZee',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtABeeZeeItalic36 = TextStyle(
    color: ColorConstant.blueGray900,
    fontSize: getFontSize(
      36,
    ),
    fontFamily: 'ABeeZee',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtABeeZeeItalic16 = TextStyle(
    color: ColorConstant.blueGray900,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'ABeeZee',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtABeeZeeRegular17WhiteA700 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'ABeeZee',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterBold20 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtABeeZeeRegular17Bluegray900 = TextStyle(
    color: ColorConstant.blueGray900,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'ABeeZee',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterBold16WhiteA700 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtAksaraBaliGalangRegular30 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      30,
    ),
    fontFamily: 'Aksara Bali Galang',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular25 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      25,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRegular20 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtABeeZeeRegular15Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'ABeeZee',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtDMSansBold14 = TextStyle(
    color: ColorConstant.teal700,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'DM Sans',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtDMSansMedium1798 = TextStyle(
    color: ColorConstant.teal700,
    fontSize: getFontSize(
      17.98,
    ),
    fontFamily: 'DM Sans',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtInterRegular50 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      50,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtDMSansRegular12Teal70066 = TextStyle(
    color: ColorConstant.teal70066,
    fontSize: getFontSize(
      12,
    ),
    fontFamily: 'DM Sans',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular30 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      30,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular10 = TextStyle(
    color: ColorConstant.blueGray700,
    fontSize: getFontSize(
      10,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterBold16 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtInterSemiBold13 = TextStyle(
    color: ColorConstant.gray900,
    fontSize: getFontSize(
      13,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w600,
  );

  static TextStyle txtInterBold17 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtPoppinsRegular14 = TextStyle(
    color: ColorConstant.blueGray90001,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtAksaraBaliGalangRegular18 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Aksara Bali Galang',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtPoppinsSemiBold25 = TextStyle(
    color: ColorConstant.blueGray90001,
    fontSize: getFontSize(
      25,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w600,
  );

  static TextStyle txtAksharRegular40 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      40,
    ),
    fontFamily: 'Akshar',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRegular16 = TextStyle(
    color: ColorConstant.blueGray400,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtABeeZeeRegular16 = TextStyle(
    color: ColorConstant.blueGray900,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'ABeeZee',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtABeeZeeRegular36Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      36,
    ),
    fontFamily: 'ABeeZee',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtABeeZeeRegular17 = TextStyle(
    color: ColorConstant.blueGray500,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'ABeeZee',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular33 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      33,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtABeeZeeRegular36 = TextStyle(
    color: ColorConstant.blueGray900,
    fontSize: getFontSize(
      36,
    ),
    fontFamily: 'ABeeZee',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtDMSansRegular12 = TextStyle(
    color: ColorConstant.teal700,
    fontSize: getFontSize(
      12,
    ),
    fontFamily: 'DM Sans',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular13Gray500 = TextStyle(
    color: ColorConstant.gray500,
    fontSize: getFontSize(
      13,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular14Gray900 = TextStyle(
    color: ColorConstant.gray900,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular34 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      34,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtABeeZeeRegular15 = TextStyle(
    color: ColorConstant.teal700,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'ABeeZee',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular12 = TextStyle(
    color: ColorConstant.blueGray700,
    fontSize: getFontSize(
      12,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular13 = TextStyle(
    color: ColorConstant.gray900,
    fontSize: getFontSize(
      13,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular35 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      35,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular36 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      36,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular14 = TextStyle(
    color: ColorConstant.blueGray700,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular15 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtDMSansRegular16 = TextStyle(
    color: ColorConstant.teal700,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'DM Sans',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular16 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtABeeZeeRegular30 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      30,
    ),
    fontFamily: 'ABeeZee',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterRegular18 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtDMSansMedium18 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'DM Sans',
    fontWeight: FontWeight.w500,
  );
}
