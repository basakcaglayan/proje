class ImageConstant {
  static String imgMastercardlogo = 'assets/images/img_mastercardlogo.png';

  static String imgStar4 = 'assets/images/img_star4.svg';

  static String imgArrowrightWhiteA700 =
      'assets/images/img_arrowright_white_a700.svg';

  static String imgImage1812x375 = 'assets/images/img_image1_812x375.png';

  static String imgInfo = 'assets/images/img_info.svg';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgEmail1 = 'assets/images/img_email1.png';

  static String imgContact1 = 'assets/images/img_contact1.png';

  static String imgContrast = 'assets/images/img_contrast.svg';

  static String imgLocationBlueGray400 =
      'assets/images/img_location_blue_gray_400.svg';

  static String imgSquash1 = 'assets/images/img_squash1.png';

  static String imgStar2 = 'assets/images/img_star2.svg';

  static String imgDumbbellsponso = 'assets/images/img_dumbbellsponso.png';

  static String imgMenu = 'assets/images/img_menu.svg';

  static String imgDelete1 = 'assets/images/img_delete1.png';

  static String imgPilates1 = 'assets/images/img_pilates1.png';

  static String imgUsericon150670 = 'assets/images/img_usericon150670.png';

  static String imgCorrect2 = 'assets/images/img_correct2.png';

  static String imgArrowright = 'assets/images/img_arrowright.svg';

  static String imgFrame124 = 'assets/images/img_frame124.svg';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgPencilg9d2a08ec1640 =
      'assets/images/img_pencilg9d2a08ec1640.png';

  static String imgEllipse2 = 'assets/images/img_ellipse2.png';

  static String imgStar325x25 = 'assets/images/img_star3_25x25.svg';

  static String imgWeightlifting1 = 'assets/images/img_weightlifting1.png';

  static String imgZumba1 = 'assets/images/img_zumba1.png';

  static String imgStar5 = 'assets/images/img_star5.svg';

  static String imgArrow1 = 'assets/images/img_arrow1.svg';

  static String imgRunwomanpng2 = 'assets/images/img_runwomanpng2.png';

  static String imgImage152x51 = 'assets/images/img_image1_52x51.png';

  static String imgSave = 'assets/images/img_save.svg';

  static String imgPlus = 'assets/images/img_plus.svg';

  static String imgSearch = 'assets/images/img_search.svg';

  static String imgHome1 = 'assets/images/img_home1.png';

  static String imgImage17 = 'assets/images/img_image17.png';

  static String imgImage1 = 'assets/images/img_image1.png';

  static String imgBullet = 'assets/images/img_bullet.svg';

  static String imgRight3 = 'assets/images/img_right3.png';

  static String imgCut = 'assets/images/img_cut.svg';

  static String imgLocation = 'assets/images/img_location.svg';

  static String imgCheckmark = 'assets/images/img_checkmark.svg';

  static String imgVisainclogo1 = 'assets/images/img_visainclogo1.png';

  static String imgLogout1 = 'assets/images/img_logout1.png';

  static String imgTennis1 = 'assets/images/img_tennis1.png';

  static String imgEye = 'assets/images/img_eye.svg';

  static String imgKickboxing1 = 'assets/images/img_kickboxing1.png';

  static String imgStar225x25 = 'assets/images/img_star2_25x25.svg';

  static String imgYogapng642 = 'assets/images/img_yogapng642.png';

  static String imgStar3 = 'assets/images/img_star3.svg';

  static String imgRectangle1153 = 'assets/images/img_rectangle1153.png';

  static String imgStar425x25 = 'assets/images/img_star4_25x25.svg';

  static String imgSwimmingpng55427 = 'assets/images/img_swimmingpng55427.png';

  static String imgStar1 = 'assets/images/img_star1.svg';

  static String imgKickboxingglov = 'assets/images/img_kickboxingglov.png';

  static String imgArrowleftBlueGray900 =
      'assets/images/img_arrowleft_blue_gray_900.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
