import 'dart:ui';
import 'package:flutter/material.dart';

class ColorConstant {
  static Color whiteA700B1 = fromHex('#b1ffffff');

  static Color whiteA700B2 = fromHex('#b2ffffff');

  static Color blueGray50 = fromHex('#efeff4');

  static Color lightGreenA400 = fromHex('#57fa0a');

  static Color teal70066 = fromHex('#660d9a57');

  static Color blueGray10001 = fromHex('#d4d7de');

  static Color blueGray900A2 = fromHex('#a2323940');

  static Color black9003f = fromHex('#3f000000');

  static Color green600 = fromHex('#34a853');

  static Color gray50 = fromHex('#f8f7f9');

  static Color red100 = fromHex('#fce2ce');

  static Color yellowA200 = fromHex('#f9ff00');

  static Color teal7001e = fromHex('#1e0d9a57');

  static Color black900 = fromHex('#000000');

  static Color teal700 = fromHex('#0d9a57');

  static Color blueGray700 = fromHex('#50555c');

  static Color blueGray90001 = fromHex('#303030');

  static Color blueGray900 = fromHex('#292d32');

  static Color blueGray5001 = fromHex('#eff2f5');

  static Color blueGray200 = fromHex('#b3bfcb');

  static Color blueGray100 = fromHex('#d9d9d9');

  static Color gray500 = fromHex('#a2a2a2');

  static Color blueGray400 = fromHex('#888888');

  static Color gray90021 = fromHex('#2112092e');

  static Color teal70099 = fromHex('#990d9a57');

  static Color gray900 = fromHex('#181819');

  static Color blueGray500 = fromHex('#6a788a');

  static Color gray4007e = fromHex('#7ec2c2c2');

  static Color gray200 = fromHex('#ebebeb');

  static Color gray40066 = fromHex('#66c2c2c2');

  static Color black90014 = fromHex('#14000000');

  static Color whiteA700 = fromHex('#ffffff');

  static Color blueGray70001 = fromHex('#46505d');

  static Color fromHex(String hexString) {
    final buffer = StringBuffer();
    if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
    buffer.write(hexString.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }
}
